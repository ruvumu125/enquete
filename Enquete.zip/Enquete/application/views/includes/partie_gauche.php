<!-- Left side column. contains the logo and sidebar -->
     <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" style="height: auto;"> 
        <!-- Sidebar user panel -->
        <div class="user-panel"> 
    <div class="pull-left image">
        
        <img src="<?php echo base_url()?>assets/dist/img/default-doctor-avatar.png" class="img-circle" alt="User Image">
        
    </div>
    <div class="pull-left info">
        <p>Londoni</p>
        <a href="#"><i class="fa fa-circle text-success"></i>En ligne</a>
    </div>
</div>       
                <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
    <li class="header">MAIN NAVIGATION</li>
    
    
    <li class="treeview <?= $dashboard ?>">
        <a href="<?php echo base_url()?>Dashboard/">
            <i class="fa fa-dashboard"></i> <span>Tableau de bord</span></a>
    </li>


    <li class="treeview <?= $gestion_reception ?>">
        <a href="#">
            <i class="fa fa-cogs"></i> <span>Enquete</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
    
            <li class="<?= $clients?>">
                <a href="<?php echo base_url()?>Enquete/"><i class="fa fa-circle-o"></i>Liste des des donnees</a>
            </li>
        </ul>
    </li>

    <!--

    <li class="treeview <?= $parametres ?>">
        <a href="#">
            <i class="fa fa-cogs"></i> <span>Gestion Bar et restaurant</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
        
            <li class="<?= $type_compte?>">
                <a href="<?php echo base_url()?>Type_compte/"><i class="fa fa-circle-o"></i>Types de comptes</a>
            </li>
            <li class="<?= $type_credit?>">
                <a href="<?php echo base_url()?>Type_credit/"><i class="fa fa-circle-o"></i>Types de crédit</a>
            </li>
            
        </ul>
    </li>

    <li class="treeview <?= $parametres ?>">
        <a href="#">
            <i class="fa fa-cogs"></i> <span>Gestion stock séminaire</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
        
            <li class="<?= $type_compte?>">
                <a href="<?php echo base_url()?>Type_compte/"><i class="fa fa-circle-o"></i>Types de comptes</a>
            </li>
            <li class="<?= $type_credit?>">
                <a href="<?php echo base_url()?>Type_credit/"><i class="fa fa-circle-o"></i>Types de crédit</a>
            </li>
            
        </ul>
    </li>

    <li class="treeview <?= $parametres ?>">
        <a href="#">
            <i class="fa fa-cogs"></i> <span>Gestion des utilisateurs</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
        
            <li class="<?= $type_compte?>">
                <a href="<?php echo base_url()?>Type_compte/"><i class="fa fa-circle-o"></i>Types de comptes</a>
            </li>
            <li class="<?= $type_credit?>">
                <a href="<?php echo base_url()?>Type_credit/"><i class="fa fa-circle-o"></i>Types de crédit</a>
            </li>
            
        </ul>
    </li>

    <li class="treeview <?= $parametres ?>">
        <a href="#">
            <i class="fa fa-cogs"></i> <span>Administration de l'application</span>
            <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
        
            <li class="<?= $type_compte?>">
                <a href="<?php echo base_url()?>Type_compte/"><i class="fa fa-circle-o"></i>Types de comptes</a>
            </li>
            <li class="<?= $type_credit?>">
                <a href="<?php echo base_url()?>Type_credit/"><i class="fa fa-circle-o"></i>Types de crédit</a>
            </li>
            
        </ul>
    </li>

-->

    
</ul>    
</section>
    <!-- /.sidebar -->
</aside><!-- Content Wrapper. Contains page content -->