<?php

    include 'includes/header.php';

?>

<?php

    include 'includes/entete.php';

?>

<?php

    $dashboard='';

    $gestion_reception='active';
    $clients='active';
    $hebergement='';
    $chambres_libres='';
    $chambres_occupes='';
    $reservation='';
    $reglement='';


    $parametres='';
    $chambres='';
    $types_chambres='';
    $services='';
    $nationalites='';


    include 'includes/partie_gauche.php';

  ?>

<div class="content-wrapper" style="min-height: 355px;overflow-y:scroll;">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1>

            Utilisateurs

           <!-- <small>Version 100.2</small> -->

        </h1>



        

    </section>



    <!-- Main content -->

    <section class="content">

        <div class="col-md-3 row pull-left" style="padding-right: 0px;">

            <a href="<?php echo base_url()?>Clients/" type="button" class="btn btn-block btn-primary pull-right btn-success">Liste des clients</a>

        </div>



        <br><br> 





        <div class="col-md-10 row">

            <div class="box box-primary">

                <div class="box-header with-border">

                    <h3 class="box-title">Ajouter un nouveau client</h3>

                </div>



                <div class="box-body">

                    <form action="<?php echo base_url()?>Clients/update" method="post" enctype="multipart/form-data">



                        <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Nom du client</label>

                        <input type="text" name="nom_client" class="form-control" placeholder="Nom du client" value="<?php echo $get_client['NOM_CLIENT']?>">

                        <?php echo form_error('nom_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>



                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Prénom du client</label>

                        <input type="text" name="prenom_client" class="form-control" placeholder="Prénom du client" value="<?php echo $get_client['PRENOM_CLIENT']?>">

                        <?php echo form_error('prenom_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>



                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Nationalité du client</label>

                        <select name="nationalite_client" class="form-control">

                          <option value="<?php echo $get_provinc['CODE_NATIONALITE']?>"><?php echo $get_provinc['NATIONALITE']?></option>

                          <?php foreach($liste_nationalites as $lista):?>

                          <option value="<?php echo $lista['CODE_NATIONALITE']?>" <?php echo set_select('nationalite_client', $lista['CODE_NATIONALITE']);?> ><?php echo $lista['NATIONALITE']?></option>

                          <?php endforeach;?>
                        </select>
                        <?php echo form_error('nationalite_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>



                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Sexe du client</label>

                        <select class="form-control select2 select2-hidden-accessible" id="consultant" name="sexe_client" style="width: 100%;" tabindex="-1" aria-hidden="true">
                            <option value="<?php echo $get_client['SEXE']?>"><?php echo $get_client['SEXE']?></option>
                                                        
                            <?php if($get_client['SEXE']!=="Masculin"):?>

                                <option value="Masculin">Masculin</option>

                            <?php endif;?>

                            <?php if($get_client['SEXE']!=="Féminin"):?>

                                <option value="Féminin">Féminin</option>

                            <?php endif;?>               
                        </select>
                        <?php echo form_error('sexe_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>



                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Adresse du client</label>

                        <input type="text" name="adresse_client" class="form-control" placeholder="Adresse du client" value="<?php echo $get_client['ADRESSE']?>">

                        <?php echo form_error('adresse_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Téléphone du client</label>

                        <input type="text" name="telephone_client" class="form-control" placeholder="Téléphone du client" value="<?php echo $get_client['TELEPHONE']?>">

                        <?php echo form_error('telephone_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>


                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Profession du client</label>
                        
                        <input type="text" name="profession_client" class="form-control" placeholder="Profession du client" value="<?php echo $get_client['PROFESSION']?>">

                        <?php echo form_error('profession_client', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label>Nature de la pièce d'identité</label>
                        
                        <select class="form-control select2 select2-hidden-accessible" id="consultant" name="nature_piece" style="width: 100%;" tabindex="-1" aria-hidden="true">
                            <option value="<?php echo $get_client['NATURE_PIECE_IDENTITE']?>"><?php echo $get_client['NATURE_PIECE_IDENTITE']?></option>

                            <?php if($get_client['NATURE_PIECE_IDENTITE']!=="Carte d’identité"):?>

                                <option value="Carte d’identité">Carte d’identité</option>

                            <?php endif;?>

                            <?php if($get_client['NATURE_PIECE_IDENTITE']!=="Passeport"):?>

                                <option value="Passeport">Passeport</option>

                            <?php endif;?>

                            <?php if($get_client['NATURE_PIECE_IDENTITE']!=="Permis de conduire"):?>

                                <option value="Permis de conduire">Permis de conduire</option>

                            <?php endif;?>

                            <?php if($get_client['NATURE_PIECE_IDENTITE']!=="Laissez-passer"):?>

                                <option value="Laissez-passer">Laissez-passer</option>

                            <?php endif;?>


                        </select>
                        <?php echo form_error('nature_piece', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label> Numéro de la pièce d'identité</label>
                        
                        <input type="text" name="num_piece" class="form-control" placeholder="Numéro de la pièce d'identité" value="<?php echo $get_client['NUMERO_PIECE_IDENTITE']?>">

                        <?php echo form_error('num_piece', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label> Place de délivrance de la pièce d'identité</label>
                        
                        <input type="text" name="place_delivrance" class="form-control" placeholder="Place de délivrance de la pièce d'identité" value="<?php echo $get_client['PLACE_DE_DELIVRANCE']?>">

                        <?php echo form_error('place_delivrance', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">

                        <label> Date de délivrance de la pièce d'identité</label>
                        
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input  type="text" class="form-control" id="dateNaissance" placeholder="sélectionner la Date" tabindex="15"  name="date_delivrance" value="<?php echo $get_client['DATE_DELIVRANCE']?>">
                        </div>
                         <?php echo form_error('date_delivrance', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      <div class="col-md-6 sm-12 xs-12 form-group">
    
                        <input type="hidden" name="code_client" class="form-control"  value="<?php echo $get_client['CODE_CLIENT']?>">

                        <?php echo form_error('place_delivrance', '<span class="text-center text-danger">', '</span>'); ?>

                      </div>

                      
                                 

                     <div class="col-md-12 sm-12 xs-12 form-group">
                         <input type="submit" value="Modifier" class="btn btn-success">
                     </div>

                    
                    </form>

                </div>



            </div>

        </div>

    </section>

    <!-- Main content -->





    

</div><!-- /.content-wrapper -->





<?php

    include 'includes/pied_page.php';

?>

<?php

    include 'includes/footer_add_patient.php';

?>

<script type="text/javascript">
    $(document).ready(function(){

        //for admission date and time
        $("#datepicker").daterangepicker({
            singleDatePicker: true,
            timePickerIncrement: 1,
            showDropdowns: true,
            timePicker: true,
            opens: "left",
            drops:"up",
            format: "DD-MM-YYYY h:mm A"
        });
        $("#dateNaissance").daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,
        //  timePicker: true,
            opens: "left",
            drops:"up",
            format: "YYYY-MM-DD"
        });
        ///Finally The Form Submit Section.

        //Gender Selector
        var selector = $("#genderSelector");
        var minInputLength = 0;
        var placeholder = "Select Gender";
        var multiple =false;
        var genderSelectorURL = "";
        commonSelect2(selector,genderSelectorURL,minInputLength,placeholder);
        $(".select2").select2();
        //Gender Selector

        
    });
</script>

<script type="text/javascript">

    $(document).ready(function(){



        //for admission date and time

        $("#datepicker").daterangepicker({

            singleDatePicker: true,

            timePickerIncrement: 1,

            showDropdowns: true,

            timePicker: true,

            opens: "left",

            drops:"up",

            format: "DD-MM-YYYY h:mm A"

        });

        ///Finally The Form Submit Section.



        //Gender Selector

        var selector = $("#genderSelector");

        var minInputLength = 0;

        var placeholder = "Select Gender";

        var multiple =false;

        var genderSelectorURL = "";

        commonSelect2(selector,genderSelectorURL,minInputLength,placeholder);



        $(".select2").select2();

        //Gender Selector



        

    });

</script>



<script type="text/javascript">

  $(document).ready(function(){

        jQuery.browser = {};

(function () {

    jQuery.browser.msie = false;

    jQuery.browser.version = 0;

    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {

        jQuery.browser.msie = true;

        jQuery.browser.version = RegExp.$1;

    }

})();

  });

</script>