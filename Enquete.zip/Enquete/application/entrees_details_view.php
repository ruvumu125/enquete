<?php
if (empty($this->session->userdata('USERNAME')))
    redirect(base_url('Login/do_logout'));

?>
<?php
    include 'includes/header.php';
?>

<?php
    include 'includes/entete.php';
?>

<?php
    
    $dashboard='';
    
    $parametres='';
    $type_compte='';
    $type_credit='';
    $province='';
    $commune='';
    $zone='';
    $colline='';
    $sous_colline='';
    $source_revenu='';
    $carriere_formation='';
    $banque='';

    $societaire='';
    $nouveau_societaire='';
    $list_societaire='';

    $rapport_fo='';
    $faire_rapport='';
    $mes_rapports='';

    $caisse='active';
    $entrees_caisse='active';
    $sorties_stock='';
    $rapport_caisse='';

    $field_officer='';
    $ajouter_field='';
    $list_field_officer='';

    $compte='';
    $nouveau_compte='';
    $list_compte='';

    $transations='';
    $epargne='';
    $retraits='';
    $rapport_transations='';

    $credits='';
    $nouveau_credits='';
    $list_credits='';
    $rapports_credits='';

    $recetttes='';
    $list_recetttes='';
    $rapport_recetttes='';

    $utilisateurs='';
    $nouveau_utilisateur='';
    $list_utilisateur='';

    $admnistration='';
    $nouveau_profil='';
    $list_profil='';

    include 'includes/partie_gauche.php';
?>

    

    
<div class="content-wrapper" style="min-height: 355px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Entrée en caisse
           <!-- <small>Version 100.2</small> -->
        </h1>
        
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-3 row pull-left" style="padding-right: 0px;">
            <a href="<?php echo base_url()?>Caisse/entrees" type="button" class="btn btn-block btn-primary pull-right btn-success">Liste des entrées en caisse</a>
        </div>

        <br><br><br>
        
        <input type="hidden" class="form-control" value="<?php echo $type_versemento['TYPE_VERSEMENT']?>" id="grande_categorie">
        <div class="row">
            
            <div class="col-md-4" id="versement_en_banque">
                 <div class="box  box-primary headerLines" style="display: block;">

                     <div class="box-header with-border">
                         <h3 class="box-title">Versement des épargnes en banque</h3>
                         <div class="box-tools pull-right">
                             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                         </div>
                     </div>

                     <div class="box-body" style="display: block;">
                         <table class="table detail">
                             <tbody>
                                 <tr>
                                     <th>Banque</th>
                                     <td><?php echo $nom_banque['NOM_BANQUE']?></td>
                                 </tr>
                                 <tr>
                                     <th>N° bordereau de versement</th>
                                     <td><?php echo $num_bordero_date_versement['NUMERO_BORDEREAU']?></td>
                                 </tr>
                                 <tr>
                                     <th>Montant versé</th>
                                     <td><?php echo $montant_vers_banque;?></td>
                                 </tr>
                                 <tr>
                                     <th>Date de versement</th>
                                     <?php
                                       $date=date("d-m-Y",strtotime($num_bordero_date_versement['DATE_VERSEMENT']));
                                       $display=' Le ' . $date.' ';
                                     ?>
                                     <td><?php echo $display?></td>
                                 </tr>
                                 <tr>
                                     <th>Versé par</th>
                                     <td><?php echo $nom_complet_fo['NOM_FAMILLE'].' '.$nom_complet_fo['PRENOM']?></td>
                                 </tr>
                                 
                             </tbody>
                         </table>
                     </div>

                 </div> 
            </div>

            <div class="col-md-4" id="versement_en_caisse">
                 <div class="box  box-primary headerLines" style="display: block;">

                     <div class="box-header with-border">
                         <h3 class="box-title">Versement des épargnes en caisse</h3>
                         <div class="box-tools pull-right">
                             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                         </div>
                     </div>

                     <div class="box-body" style="display: block;">
                         <table class ="table detail">
                             <tbody>
                                 
                                 <tr>
                                     <th>Numero du rapport</th>
                                     <td><?php echo $num_rapport['NUMERO_RAPPORT']?></td>
                                 </tr>
                                 <tr>
                                     <th>Date de redation</th>
                                     <?php
                                       $date=date("d-m-Y",strtotime($date_redaction['DATE']));
                                       $time=date("H:i:s",strtotime($date_redaction['DATE']));
                                       $display=' Le ' . $date.' à '.$time;
                                     ?>
                                     <td><?php echo $display;?></td>
                                 </tr>
                                 <tr>
                                     <th>Redige par </th>
                                     <td><?php echo $nom_complet_field['NOM_FAMILLE'].' '.$nom_complet_field['PRENOM']?></td>
                                 </tr>
                                 <tr>
                                     <th>Montant verse</th>
                                     <td><?php echo $montant_vers_caisse?></td>
                                 </tr>
                                 <tr>
                                     <th>Date de versement</th>
                                     <?php
                                       $date=date("d-m-Y",strtotime($date_vers_caisse));
                                       $time=date("H:i:s",strtotime($date_vers_caisse));
                                       $display=' Le ' . $date.' à '.$time;
                                     ?>
                                     <td><?php echo $display?></td>
                                 </tr>
                                 
                                 
                             </tbody>
                         </table>
                     </div>

                 </div>
            </div>

            <div class="col-md-4" id="autres_motif">
                 <div class="box  box-primary headerLines" style="display: block;">

                     <div class="box-header with-border">
                         <h3 class="box-title">Autres entrees</h3>
                         <div class="box-tools pull-right">
                             <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                         </div>
                     </div>

                     <div class="box-body" style="display: block;">
                        <table class="table detail">
                             <tbody>
                                 
                                 <tr>
                                     <th>Montant</th>
                                     <td><?php echo $montant_vers_autres?></td>
                                 </tr>
                                 <tr>
                                     <th>Date de versement</th>
                                     <?php
                                       $date=date("d-m-Y",strtotime($date_vers_autres));
                                       $time=date("H:i:s",strtotime($date_vers_autres));
                                       $display=' Le ' . $date.' à '.$time;
                                     ?>
                                     <td><?php echo $display?></td>
                                 </tr>
                                 <tr>
                                     <th>Motif</th>
                                     <td><?php echo $motif_autres['MOTIF']?></td>
                                 </tr>
                                 <tr>
                                     <?php if(!empty($motif_autres['DETAILS'])):?>
                                     <th>Détails</th>
                                     <td><?php echo $motif_autres['DETAILS']?></td>
                                    <?php endif;?>
                                 </tr>
                                 
                                 
                             </tbody>
                         </table>
                         


                     </div>

                 </div>
            </div>
            



        </div>

        
    </section>
    <!-- Main content -->


    
</div><!-- /.content-wrapper -->


<?php
    include 'includes/pied_page.php';
?>


<?php
    include 'includes/footer.php';
?>
<script type="text/javascript">
    $(document).ready(function(){

        //for admission date and time
        $("#datepicker").daterangepicker({
            singleDatePicker: true,
            timePickerIncrement: 1,
            showDropdowns: true,
            timePicker: true,
            opens: "left",
            drops:"up",
            format: "DD-MM-YYYY h:mm A"
        });
        ///Finally The Form Submit Section.

        //Gender Selector
        var selector = $("#genderSelector");
        var minInputLength = 0;
        var placeholder = "Select Gender";
        var multiple =false;
        var genderSelectorURL = "";
        commonSelect2(selector,genderSelectorURL,minInputLength,placeholder);

        $(".select2").select2();
        //Gender Selector

        
    });
</script> 

<!--On page load hide -->
<script type="text/javascript">
  $(window).on("load", function () {
    
    var MOTIF=$("#grande_categorie" ).val();
 


  if (MOTIF=="Versement des épargnes en banque") {

    $('#autres_motif').hide();
    $('#versement_en_caisse').hide();
    $('#versement_en_banque').show();

  }
  else if (MOTIF=="Versement des épargnes en caisse") {

    $('#autres_motif').hide();
    $('#versement_en_caisse').show();
    $('#versement_en_banque').hide();


  }
  else if (MOTIF=="Autres") {

    $('#autres_motif').show();
    $('#versement_en_caisse').hide();
    $('#versement_en_banque').hide();
  }
    
   
});
</script>
<!--On page load hide-->