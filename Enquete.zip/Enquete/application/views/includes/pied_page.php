<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright © <?php echo date('Y')?> <a href="">Coopérative Goshen</a>.</strong> All rights reserved.
</footer>