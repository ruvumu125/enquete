<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Enquete extends CI_Controller {

  
  public function index()
  {

    $listofbanque=array();
        $list_banque=$this->Model->getList('enquete');

        foreach ($list_banque as $prov) {

          $date=date("d-m-Y",strtotime($prov['RESPONDENT_DOB']));
          $time=date("H:i:s",strtotime($prov['RESPONDENT_DOB']));
          $display=' Le ' . $date.' à '.$time;

          $listofbanque[]=array(

               'id_menage'=>$prov['MENAGE_ID'],
               'latitude'=>$prov['MENAGE_LOCATION_LAT'],
               'longitude'=>$nationalite['MENAGE_LOCATION_LNG'],
               'nom_repondant'=>$prov['REPONDANT_NOM'],
               'age_repondant'=>$prov['REPONDANT_AGE'],
               'date_naissance'=>$display,
               'nombre_personnes'=>$prov['HH_PEOPLE_NB'],
             
               
               'update'=>'<a class="btn btn-success btn-xs" href="' . base_url("Clients/index_update/") .$prov['MENAGE_ID'] . '" style="width:120px;"><i class="fa fa-edit"></i> Modifier </a>

               <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" 
                            data-target="#mydelete'.$prov['CODE_CLIENT'] .'" style="margin-top:5px;width:120px;"><i class="fa fa-trash"></i> Supprimer </button>
                <div class="modal fade" id="mydelete'.$prov['CODE_CLIENT'].'">
         <div class="modal-dialog">
          <div class="modal-content">
           <div class="modal-body">
            <h5>Voulez vous vraiment supprimer l\'enque du menage   '.$prov['MENAGE_ID'].'?</h5>
           </div>
           <div class="modal-footer">
             <a class="btn  btn-primary btn-md" href="'.base_url("Clients/delete/".$prov['MENAGE_ID']).'">Supprimer</a>
             <button class="btn  btn-md" class="close" data-dismiss="modal">Annuler</button>
           </div>
          </div>
         </div>
        </div>'

               
          );
        }
        $data['list']=$listofbanque; 
        $templates=array(
         'table_open' => '<table class="table table-bordered table-stripped table-hover table-condensed" id="table_id"> ',
         'table_close'  => '</table>');
         $this->table->set_heading(array('Identifiant du ménage','Latitude','Longitude','Nom du répondant','Age du répondant','Date de naissance','Nombre de personnes du foyer','Options'));

         $this->table->set_template($templates);
     $this->load->view('clients_list_view',$data);
  }
  
  public function delete(){

    $table ='client';
    $criteres['CODE_CLIENT']=$this->uri->segment(3);
    $data['rows']= $this->Model->getOne( $table,$criteres);

    $this->Model->delete($table,$criteres);
    $this->session->set_flashdata('feedback', 'Supprimé');

    redirect(base_url('Clients/'));
  }
}
