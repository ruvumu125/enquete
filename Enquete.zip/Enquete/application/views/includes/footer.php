</div><!-- ./wrapper -->
<div class="overlay" style="display: none;">
    <i class="fa fa-refresh fa-spin"></i>
</div>
<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url()?>assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script src="<?php echo base_url()?>assets/highcharts/highcharts.js"></script>
<script src="<?php echo base_url()?>assets/highcharts/modules/exporting.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>
<!-- Jquery noty -->
<script src="<?php echo base_url()?>assets/plugins/noty/packaged/jquery.noty.packaged.js"></script>
<!-- Haider -->
<script src="<?php echo base_url()?>assets/dist/js/Haider.js"></script>
<!-- Custom Page Scripting -->
<script src="<?php echo base_url()?>assets/dist/js/customScripting.js"></script>
<script src="<?php echo base_url()?>assets/plugins/datatables/datatables.min.js"></script>

<!--Extra Scripts Included By Pages ItSelf-->

    <!-- Select2 -->
        <!-- date-range-picker -->
      <script src="<?php echo base_url()?>assets/dist/js/moment.min.js"></script>
      <script src="<?php echo base_url()?>assets/plugins/daterangepicker/daterangepicker.js"></script>
      <!-- Select 2 -->
      <script src="<?php echo base_url()?>assets/plugins/select2/select2.full.min.js"></script>
      <script src="<?php echo base_url()?>assets/dist/js/app.min.js"></script>
      <!-- InputMask -->
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.js"></script>
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.extensions.js"></script>




</body>
</html>