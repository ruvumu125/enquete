<?php
if (empty($this->session->userdata('USERNAME')))
    redirect(base_url('Login/do_logout'));

?>
<?php
    include 'includes/header.php';
?>

<?php
    include 'includes/entete.php';
?>

<?php
    $dashboard='';
    
    $parametres='active';
    $type_compte='';
    $type_credit='';
    $province='';
    $commune='';
    $zone='';
    $colline='';
    $sous_colline='';
    $source_revenu='';
    $carriere_formation='active';
    $banque='';

    $rapport_fo='';
    $faire_rapport='';
    $mes_rapports='';

    $caisse='';
    $entrees_caisse='';
    $sorties_stock='';
    $rapport_caisse='';

    $field_officer='';
    $ajouter_field='';
    $list_field_officer='';

    $societaire='';
    $nouveau_societaire='';
    $list_societaire='';

    $compte='';
    $nouveau_compte='';
    $list_compte='';

    $transations='';
    $epargne='';
    $retraits='';
    $rapport_transations='';

    $credits='';
    $nouveau_credits='';
    $list_credits='';
    $rapports_credits='';

    $recetttes='';
    $list_recetttes='';
    $rapport_recetttes='';

    $utilisateurs='';
    $nouveau_utilisateur='';
    $list_utilisateur='';

    $admnistration='';
    $nouveau_profil='';
    $list_profil='';

    include 'includes/partie_gauche.php';
?>

    

    
<div class="content-wrapper" style="min-height: 355px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Carrière de formation
           <!-- <small>Version 100.2</small> -->
        </h1>
        
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="col-md-3 row pull-left" style="padding-right: 0px;">
            <a href="<?php echo base_url()?>Carriere_formation/" type="button" class="btn btn-block btn-primary pull-right btn-success">Liste des carrières de formation</a>
        </div>

        <br><br>


        <div class="col-md-6 row">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Ajouter une nouvelle carrière de formation</h3>
                </div>

                <div class="box-body">
                    <form action="<?php echo base_url()?>Carriere_formation/add" method="post">
                        <div class="form-group">
                            <label>Nom de la carrière Formation</label>
                            <input class="form-control" type="text" name="desc_carriere" placeholder="Nom de la carrière Formation">
                            <?php echo form_error('desc_carriere', '<span class=text-center text-danger>', '</span>'); ?>
                        </div>

                      

                        <input type="submit" value="Enregistrer" class="btn btn-primary">
                    </form>
                </div>

            </div>
        </div>
    </section>
    <!-- Main content -->


    
</div><!-- /.content-wrapper -->


<?php
    include 'includes/pied_page.php';
?>


<?php
    include 'includes/footer.php';
?>
<script type="text/javascript">
    $(document).ready(function(){

        //for admission date and time
        $("#datepicker").daterangepicker({
            singleDatePicker: true,
            timePickerIncrement: 1,
            showDropdowns: true,
            timePicker: true,
            opens: "left",
            drops:"up",
            format: "DD-MM-YYYY h:mm A"
        });
        ///Finally The Form Submit Section.

        //Gender Selector
        var selector = $("#genderSelector");
        var minInputLength = 0;
        var placeholder = "Select Gender";
        var multiple =false;
        var genderSelectorURL = "";
        commonSelect2(selector,genderSelectorURL,minInputLength,placeholder);

        $(".select2").select2();
        //Gender Selector

        
    });
</script>