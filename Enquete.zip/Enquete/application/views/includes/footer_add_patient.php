</div><!-- ./wrapper -->
<div class="overlay" style="display: none;">
    <i class="fa fa-refresh fa-spin"></i>
</div>
<!-- jQuery 2.1.4 -->

<script src="<?php echo base_url()?>assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>

<!-- Bootstrap 3.3.5 -->
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo base_url()?>assets/multiselect/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="<?php echo base_url()?>assets/multiselect/bootstrap-multiselect.css" type="text/css"/>
<!-- Jquery noty -->
<script src="<?php echo base_url()?>assets/plugins/noty/packaged/jquery.noty.packaged.js"></script>
<!-- Haider -->
<script src="<?php echo base_url()?>assets/dist/js/Haider.js"></script>
<!-- Custom Page Scripting -->
<script src="<?php echo base_url()?>assets/dist/js/customScripting.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>



<!--Extra Scripts Included By Pages ItSelf-->

    <!-- Select2 -->
        <!-- date-range-picker -->
      <script src="<?php echo base_url()?>assets/dist/js/moment.min.js"></script>
      <script src="<?php echo base_url()?>assets/plugins/daterangepicker/daterangepicker.js"></script>
      <!-- Select 2 -->
      <script src="<?php echo base_url()?>assets/plugins/select2/select2.full.min.js"></script>
      <script src="<?php echo base_url()?>assets/dist/js/app.min.js"></script>
      <!-- InputMask -->
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.js"></script>
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
       <script src="<?php echo base_url()?>assets/plugins/input-mask/jquery.inputmask.extensions.js"></script>

       <script type="text/javascript" src="<?php echo base_url()?>assets/bootstrap-fileupload/bootstrap-fileupload.js"></script>
       <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/jquery.validate.js"></script>
       <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.1/additional-methods.js"></script>




</body>
</html>