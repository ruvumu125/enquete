<?php

if (empty($this->session->userdata('USERNAME')))

    redirect(base_url('Login/do_logout'));



?>

<?php

    include 'includes/header.php';

?>



<?php

    include 'includes/entete.php';

?>



<?php

    

    $dashboard='';

    

    $parametres='';

    $type_compte='';

    $type_credit='';

    $province='';

    $commune='';

    $zone='';

    $colline='';

    $sous_colline='';

    $source_revenu='';

    $carriere_formation='';

    $banque='';

    $mes_societaires='';
    $mes_comptes='';
    $list_rapports='';
    $mes_comptes='';

    $mes_demandes_retraits='active';
    $liste_demande_retraits='';
    $mes_demandes_credits='';
    $liste_demandes_credits='';



    $societaire='';

    $nouveau_societaire='';

    $list_societaire='';



    $rapport_fo='';

    $faire_rapport='';

    $mes_rapports='';



    $caisse='';

    $entrees_caisse='';

    $sorties_stock='';

    $rapport_caisse='';



    $field_officer='';

    $ajouter_field='';

    $list_field_officer='';



    $compte='';

    $nouveau_compte='';

    $list_compte='';



    $transations='active';

    $epargne='';

    $retraits='';

    $rapport_transations='';



    $credits='';

    $nouveau_credits='';

    $list_credits='';

    $rapports_credits='';



    $recetttes='';

    $list_recetttes='';

    $rapport_recetttes='';



    $utilisateurs='';

    $nouveau_utilisateur='';

    $list_utilisateur='';



    $admnistration='';

    $nouveau_profil='';

    $list_profil='';



    include 'includes/partie_gauche.php';

?>



 <style type="text/css">

    .flashmessage {

    background: #4cb445;

    color: #f1f1f1;

    padding: 3px;

    font-size: 21px;

    text-align: center;

    width: 212px;

    margin-left: 20px;

    margin-top: 10px;

}

.pull-left {

    float: left!important; 

} 

 </style>    



    

<div class="content-wrapper" style="min-height: 355px;">

    <!-- Content Header (Page header) -->

    <section class="content-header">

        <h1>

            Demande de Retrait

           <!-- <small>Version 100.2</small> -->

        </h1>

        

    </section>

    

    <!--Message de succes-->

    <?php $message = $this->session->flashdata('feedback');?>

    <?php if(!empty($message)):?>

      <div class="flashmessage text-center"><i class="fa fa-check"></i> <?php echo $message; ?></div>

    <?php endif;?>

    <!--Fin Message de succes-->

    

    <!-- Main content -->

    <section class="content">

        <div class="row">



            <div class="col-md-12">

                <div class="box box-primary">

                    <div class="box-header with-border">

                        <h3 class="box-title">Liste de touters les demandes de retraits</h3>

                    </div>



                    <div class="box-body">

                        <?= $this->session->flashdata('message') ?>

                       <br>

                       <?php echo $this->table->generate($list);?>

                    </div>



                </div>

            </div>





        </div><!-- /.row -->

    </section><!-- /.content -->





    

</div><!-- /.content-wrapper -->





<?php

    include 'includes/pied_page.php';

?>



<?php

    include 'includes/footer.php';

?>



<script>

   

$(document).ready(function(){

  

    $(document).ready( function () {

    $('#table_id').DataTable({



      "columnDefs": [

    { "width": "10%", "targets": 0 },{ "width": "10%", "targets": 1 }

  ]

    });

} );

  });

</script>



<script>

  

$(document).ready(function(){

  

   setTimeout(function(){  

                               $('.flashmessage').fadeOut("Slow");  

                          }, 3000);

  });

</script>