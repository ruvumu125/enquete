<?php
//23.03.2018 Ghislain
// Menu
$lang['menu_principal_un']="Tableaux de bord";
$lang['menu_principal_deux']="IHM";
$lang['menu_principal_trois']="Monitoring";
$lang['menu_principal_quatre']="Reporting";
$lang['menu_principal_cinq']="SMS";
$lang['menu_principal_six']="Administration";
$lang['menu_principal_langue_un']="English";
$lang['menu_principal_langue_deux']="Français";
$lang['menu_principal_langue_trois']="Ikirundi";
$lang['menu_principal_logout']="D&eacute;connexion";


// projet views

$lang['projet_view_add_title']="Ajout d'un Projet";
$lang['projet_view_add_nom']="Nom";
$lang['projet_view_add_description']="Description";
$lang['view_ihm_save_btn']="Enregistrer";
$lang['view_ihm_updtate_btn']="Modifier";
$lang['projet_view_liste_title']="Liste des Projets";
$lang['projet_view_update_title']="Modification d'un Projet";


// projet controller
$lang['projet_crontrol_add_nom']="Nom du Projet";
$lang['projet_crontrol_add_succes1']="Enregistement du projet ";
$lang['projet_crontrol_add_succes2']=" fait avec succes";
$lang['projet_crontrol_delete_warning1']="Voulez-vous vraiment Supprimer le Projet ";
$lang['projet_crontrol_delete_warning2']="?";
$lang['projet_crontrol_btn_cancel']="Annuler";
$lang['projet_crontrol_btn_delete']="Supprimer";
$lang['projet_crontrol_update_fail']="Ce Projet exite déjà";
$lang['projet_crontrol_update_succes1']="Modification du projet ";
$lang['projet_crontrol_update_succes2']=" fait avec succès";
$lang['projet_crontrol_delete_succes']="Projet supprimé avec succès";


// site views

$lang['site_view_add_title']="Ajout d'une site";
$lang['site_view_add_projet']="Projet";
$lang['site_view_add_select']="Selectioner";
$lang['site_view_add_adress']="Adresse";
$lang['site_view_add_lat']="Latitude";
$lang['site_view_add_long']="Longitude";
$lang['site_view_add_province']="Province";
$lang['site_view_add_commune']="Commune";
$lang['site_view_list_title']="Liste des sites";
$lang['site_view_update_title']="Modification d'une site";


// site controller


$lang['site_crontrol_add_nom']="Nom du site";
$lang['site_crontrol_add_succes1']="Enregistement du site ";
$lang['site_crontrol_add_succes2']=" fait avec succes";
$lang['site_crontrol_add_fail']="Le site exite déjà";
$lang['site_crontrol_add_nomprenom']="Nom et Prénom";
$lang['site_crontrol_add_role']="Tâche ";
$lang['site_crontrol_add_tel']="Tél";
$lang['site_crontrol_add_email']="Email ";
$lang['site_crontrol_add_ajouterpersone']="Ajouter une autre personne sur le site";
$lang['site_crontrol_add_nompersone']="Nom de la Personne";
$lang['site_crontrol_add_typeperso']="Type de personne";
$lang['site_crontrol_add_btn_fermer']="Fermer";
$lang['site_crontrol_update_success1']="la Modification du site ";
$lang['site_crontrol_update_success2']=" bien faite";
$lang['site_crontrol_delete_success1']="Suppression du site ";
$lang['site_crontrol_delete_success2']=" bien faite";

// personel views

$lang['personel_view_add_title']="Ajout d'un utilisateur";
$lang['personel_view_add_nom']="Nom";
$lang['personel_view_add_prenom']="Prénom ";
$lang['personel_view_add_telephone']="Téléphone";
$lang['personel_view_list_title']="Liste du personnel ";
$lang['personel_view_update_title']="Modification d'un personnel";
$lang['personel_view_listew_title']="Liste du personnel ";
$lang['personel_view_listew_profils']="Profil ";

// personel controler
$lang['personel_crontrol_add_fail1']="Le personnel porte le numéro de téléphone ou Email déjà enregistré";
$lang['personel_crontrol_add_sussec1']="Enregistrement de ";
$lang['personel_crontrol_add_sussec2']=" fait avec succès";
$lang['personel_crontrol_add_droitnotd']="Droit au system non défini";
$lang['personel_crontrol_add_droit']="Autoriser à";
$lang['personel_crontrol_delete_warnig']="Voulez-vous supprimer le personnel";
$lang['personel_crontrol_update_success1']="la Modification du personnel ";
$lang['personel_crontrol_update_success2']=" bien faite ";
$lang['personel_crontrol_update_droit1']=" Droit et Mot de passe modifiés consulter le mail(";
$lang['personel_crontrol_update_droit2']=") de";
$lang['personel_crontrol_update_droit3']=" ";
$lang['personel_crontrol_update_creedroit1']=" Droit et Mot de passe créer consulter le mail (";
$lang['personel_crontrol_update_creedroit2']=") de ";
$lang['personel_crontrol_update_creedroit3']=" ";
$lang['personel_crontrol_delete_succes1']=" Suppression du personnel";
$lang['personel_crontrol_delete_succes2']=" bien faite";


// entreprise views

$lang['entreprise_view_add_title']="Ajout d'une entreprise";
$lang['entreprise_view_update_title']="Modification d'une entreprise";
$lang['entreprise_view_liste_title']="Liste des entreprises ";

// entreprise controllers

$lang['personel_crontrol_add_fail']="cette entreprise exite déjà";
$lang['personel_crontrol_add_succes1']="Enregistrement de l'entreprise  ";
$lang['personel_crontrol_add_succes2']=" fait avec succès";
$lang['personel_crontrol_update_nom']="Nom de l\'entreprise ";
$lang['personel_crontrol_update_succes1']="la Modification de l\'entreprise ";
$lang['personel_crontrol_update_succes2']=" bien faite ";
// $lang['personel_crontrol_add_title']="Nom de l\'entreprise ";





//persone anotifier

$lang['ev_persone_notifier_add_titre']=" Ajout d'une personne à notifier";
$lang['ev_persone_notifier_nom']=" Nom";
$lang['ev_persone_notifier_prenom']=" Prénom";
$lang['ev_persone_notifier_title']=" Titre";
$lang['ev_persone_notifier_mail']=" Mail";
$lang['ev_persone_notifier_phone']=" Téléphone";
$lang['ev_persone_notifier_enregistrer']=" Enregistrer";

// personne a notifier liste
$lang['ev_persone_notifier_liste']=" Liste des personnes à notifier";

//personne a notifier update 

$lang['ev_persone_notifier_modification']=" Modification d'une personne à notifier ";
$lang['ev_persone_notifier_update_nom']=" Nom";
$lang['ev_persone_notifier_update_prenom']=" Prénom";
$lang['ev_persone_notifier_update_titre']=" Titre";
$lang['ev_persone_notifier_update_mail']=" Mail";
$lang['ev_persone_notifier_update_phone']=" Téléphone";
$lang['ev_persone_notifier_update_enregistrer']=" Enregistrer";


// Personnne a notifier Controller
$lang['notif_crontrol_add_fail']="La personne exite d&eacute;ja&agrave; dans la base de donn&eacute;e";
$lang['notif_crontrol_add_succes']=" Enregistrement de la personne faite avec succes";
$lang['notif_crontrol_delet_warning1']="Voulez vous vraiment Supprimer de la liste des notifications ";
$lang['notif_crontrol_delet_warning2']=" ?";
$lang['notif_crontrol_update_ok']="Modification fait avec succes";
$lang['notif_crontrol_delete_succes']=" Personne &agrave; notifier effac&eacute; avec succes";




//sms

$lang['ev_persone_notifier_configue_liste_msg']=" Liste des messages";


//sms controller

$lang['ghi_persone_notifier_configue_contr_msg_r']="Message récu";
$lang['ghi_persone_notifier_configue_contr_msgrep']="Message réponse";
$lang['ghi_persone_notifier_configue_contr_phone']="Télephone";





//Monitoring Views


$lang['monitoring_view_title']="Sites ABUTIP sur carte";
$lang['monitoring_view_smal_title']="Geolocalisation par";



//IHM include Views

$lang['ihm_include_addition']="Ajouter";
$lang['ihm_include_listing']="Liste";

$lang['ihm_include_project']="Projet";
$lang['ihm_include_site']="Sites";
$lang['ihm_include_entre']="Entreprises";
$lang['ihm_include_personel']="Utilisateur";
$lang['ihm_include_personel_chantier']="Personnel du chantier";
$lang['ihm_include_planites']="Plaintes";
$lang['ihm_include_personel_notifier']="Personne à notifier";
$lang['ihm_include_personel_definirdroit']="Définir les droits";
$lang['ihm_include_plainte_par_chantier']="Par chantier";
$lang['ihm_include_plainte_par_type']="Par type/transmission";
$lang['ihm_include_plainte_par_etat']="Par Etat";



// Plainte Views

$lang['plaintes_add_title']="Enregistrement d'une plainte";
$lang['plaintes_add_navbar_lieu_et_date']="Lieux et Date";
$lang['plaintes_add_navbar_plaignant']="Plaignant(e)";
$lang['plaintes_add_navbar_details_plaintes']="Détails Plainte";
$lang['plaintes_add_projet']="Projet";
$lang['plaintes_add_site']="Site";
$lang['plaintes_add_province']="Province";
$lang['plaintes_add_commune']="Commune";
$lang['plaintes_add_colline']="Colline";
$lang['plaintes_add_village']="Village";
$lang['plaintes_add_date']="Date";
$lang['plaintes_add_nom']="Nom";
$lang['plaintes_add_telephone']="Téléphone";
$lang['plaintes_add_plainte_via']="Plainte Via";
$lang['plaintes_add_details_grief']="Détails du Grief";
$lang['plaintes_add_info_deataile_plainte']="Information Detaille de la plainte";
$lang['plaintes_add_info_gestion_grief']="Information sur la gestion du grief";
$lang['plaintes_add_joindre_photodoc']="Joindre Document/Photo";
$lang['plaintes_add_autre']="Autre";
$lang['plaintes_add_suivant']="Suivant";
$lang['plaintes_add_Precedent']="Precedent";
$lang['plaintes_details_doc_connexes']="Voir documents connexes";
$lang['plaintes_details_telechargepdf']="Telecharger PDF";
$lang['plaintes_details_historique']="Historique";
$lang['plaintes_details_plainte_num']="Plainte num";
$lang['plaintes_details_commentaire']="Commentaires";
$lang['plaintes_details_etat']="Etat";
$lang['plaintes_details_documents']="Documents";
$lang['plaintes_details_fermer']="Fermer";
$lang['plaintes_details_gest_plainte']="Gestion de la plainte";
$lang['plaintes_details_num_plainte']="No de plainte";
$lang['plaintes_details_nom_enregistre']="Plainte enregistré par";
$lang['plaintes_details_prov_comm']="Province/Commune/Colline/Village";
$lang['plaintes_details_envoye']="Copie envoyee a";
$lang['plaintes_details_partie']="Partie Recepteur";
$lang['plaintes_details_partie_respo']="Partie responsable";
$lang['plaintes_details_copie_pour_base']="Copie pour base de donne";
$lang['plaintes_details_copie_demandeur']="Copie pour le demendeur";
$lang['plaintes_details_info_plaignant']="Information sur le plaignant(e)";
$lang['plaintes_details_Adress_plaignant']="Adress";
$lang['plaintes_details_plainte_recu_par']="Plainte recu via";
$lang['plaintes_details_info_sur_plainte']="Information sur la plainte";
$lang['plaintes_details_detailsgrief']="Détails du grief (A)";
$lang['plaintes_details_desc_plainte_grief']="Description de plainte/grief";
$lang['plaintes_details_desc_action_requise']="Description d'action requise";
$lang['plaintes_details_doc_annexe']="Document annexe à la plainte";
$lang['plaintes_details_historique_plainte']="Historique de la plainte";
$lang['plaintes_details_date_heure']="Date et Heure";
$lang['plaintes_details_desc']="Description";
$lang['plaintes_details_etat']="Etat";
$lang['plaintes_details_personnel']="Personel";
$lang['plaintes_Document_view_telechargerpdf']="Télecharger PDF de la plainte et toute l'historique";
$lang['plaintes_Document_view_doc_cette_plainte']="Documents de cette plaintes";
$lang['plaintes_list_title']="Liste des plaintes";
$lang['pdf_creation_plaintes_cloture_last']="Gestion de la plainte";
$lang['pdf_creation_plaintes_cloture_view']="Bon de livraison";
$lang['pdf_creation_plaintes_cloture_view_resolu']="Plainte résolu. En attente du procès-verbal de cloture";
$lang['pdf_creation_plaintes_cloture_view_commentstatu']="Commenter et changer de statut";
$lang['pdf_creation_plaintes_cloture_view_annexedate']="annex&eacute; le ";
$lang['pdf_creation_plaintes_cloture_view_motcloture']="Mot de Clôture ";

 


 

//Plainte controller


$lang['plainte_crontrol_add_comentnull']="vous n\'avez pas mis de commentaire";
$lang['plainte_crontrol_add_ok']="Commentaire bien enregistré";
$lang['plainte_crontrol_add_cloturenull']="Vous n'avez joint aucun fichier relatif à la clôture de la plainte  ";
$lang['plainte_crontrol_add_valid_prov']="province de la plainte ";
$lang['plainte_crontrol_add_valid_commu']="commune de la plainte ";
$lang['plainte_crontrol_add_valid_date']="date";
$lang['plainte_crontrol_add_valid_plaintevia']="Plainte Via ";
$lang['plainte_crontrol_add_valid_grif']="Grieff";
$lang['plainte_crontrol_add_valid_detplainte']="Détails de la plainte ";
$lang['plainte_crontrol_add_valid_gestiongr']=" Gestion grief  ";
$lang['plainte_crontrol_add_fail']="Plainte déjà enregistré";
$lang['plainte_crontrol_add_suceess']=" Plainte bien enregistrée ";
$lang['plainte_crontrol_add_detail_le']="Date";
$lang['plainte_crontrol_add_detail_personnel']="Personnel";
$lang['plainte_crontrol_add_detail_etat']="Etat";
$lang['plainte_crontrol_view_doc']="Voir le document";
$lang['plainte_crontrol_view_visionner']="Visionner";
$lang['plainte_crontrol_bread_start']="Accueil";
$lang['plainte_crontrol_bread_one']="Plaintes";
$lang['plainte_crontrol_bread_two']="Plainte num:";


$lang['plainte_crontrol_add_fail1']="Vous n'etes pas enregistré comme personnel travaillant sur un site";


//Landry composition_site
$lang['composition_chantier_add_title']="Composition d'un site";
$lang['composition_chantier_add_site']="Site";
$lang['composition_chantier_add_selectionner']="Selectioner";
$lang['composition_chantier_add_entreprise']="Entreprise";
$lang['composition_chantier_add_entrepr']="Entreprise";
$lang['composition_chantier_add_sous_title']="Personnel affecté au site";
$lang['composition_chantier_add_personnel']="Personnel";
$lang['composition_chantier_add_type_personnel']="Type du personnel";
$lang['composition_chantier_list_title']="Liste des constituants du chantier";
$lang['composition_chantier_update_title']="Modification des constituants d'une site";
$lang['composition_chantier_list_denomination']="Dénomination";
$lang['composition_chantier_list_entr_attr']="Entreprise attributaire";
$lang['composition_chantier_list_charg']="Chargés de Projet ";
$lang['composition_chantier_list_nom_pren']="Nom de la Personne";
$lang['composition_chantier_list_role']="Rôle";
$lang['composition_chantier_list_tel']="Tél";
$lang['composition_chantier_list_email']="Email";
$lang['composition_chantier_list_change_entr']="Changer d'entreprise";
$lang['composition_chantier_list_nom_pers']="Nom de la Personne";
$lang['composition_chantier_list_sel']="Selectioner";
$lang['composition_chantier_list_ajout_pers']="Ajouter une autre personne sur le site";
$lang['composition_chantier_list_typ_pers']="Type de personne";
$lang['composition_chantier_list_fermer']="Fermer";
$lang['composition_chantier_list_enreg']="Enregistrer les changements";
$lang['composition_chantier_update_site']="Site";
$lang['composition_chantier_update_entreprise']="Entreprise";
$lang['composition_chantier_update_personnel']="Personnel";
$lang['composition_chantier_update_type_pers']="Type du personnel";


//composition site controller

$lang['compo_site_crontrol_add_site']="Site";
$lang['compo_site_crontrol_add_entreprise']="entreprise";
$lang['compo_site_crontrol_add_persone']="Nom de la personne";
$lang['compo_site_crontrol_add_role']="Role de la persone ";
$lang['compo_site_crontrol_add_succes1']="L'enregistrement de la composition du site ";
$lang['compo_site_crontrol_add_succes2']=" bien fait";
$lang['comp_site_crontrol_update_succes1']="Modification de la  compostion du site ";
$lang['comp_site_crontrol_update_succes2']=" bien faite";
$lang['comp_site_crontrol_update_addperson']="Ajouter une autre personne sur le site ";
$lang['comp_site_crontrol_update_entfail1']=" l\'entreprise  ";
$lang['comp_site_crontrol_update_entfail2']="était enregistrée sur ce site";
$lang['comp_site_crontrol_delete_succes1']=" Suppression du site ";
$lang['comp_site_crontrol_delete_succes2']=" bien faite";
$lang['comp_site_crontrol_add_personne_role']="role";
$lang['comp_site_crontrol_add_personne_faile']="La personne selectionée est déjà enregistrée sur ce site";


//27.03.2018 création plainte

$lang['ev_creation_plainte_title']=" ::Plainte / Complaint";

$lang['ev_creation_plainte_gestion']=" Gestion de la plainte / Complaint Management";
$lang['ev_creation_plainte_no']=" No de plainte / Complaint number";
$lang['ev_creation_plainte_nom']=" Nom de l'enregistreur / Name of the registering person";
$lang['ev_creation_plainte_prov_coll_vill']="Province/Commune/Colline/Village";
$lang['ev_creation_plainte_date']="Date / Date";
$lang['ev_creation_plainte_copie']="Copie envoyé à /Copy sent to :";
$lang['ev_creation_plainte_partie']="Partie Récepteur / Receiver part:";
$lang['ev_creation_plainte_partie_resp']="Partie responsable / Responsible part:";
$lang['ev_creation_plainte_partie_copie_base']="Copie pour base de donnée / Database copy:";
$lang['ev_creation_plainte_partie_sauvegarde']="Sauvegardé dans le système / Saved in the system";
$lang['ev_creation_plainte_copie_demandeur']="Copie pour le demandeur / Applicant copy :";
$lang['ev_creation_plainte_info_plaignant']="Information sur le plaignant(e) / Information on the complainant";
$lang['ev_creation_plainte_nomm']="Nom / Name";
$lang['ev_creation_plainte_adresse']="Adresse / Address";
$lang['ev_creation_plainte_tel']="Tel / Tel";
$lang['ev_creation_plainte_email']="Email / Email";
$lang['ev_creation_plainte_recu_par']="Plainte recue par / Complaint received by :";
$lang['ev_creation_plainte_info_plainte']="Information sur la plainte / Information on the complaint";
$lang['ev_creation_plainte_detail']="D&eacute;tails du grief (A) / Grief details";
$lang['ev_creation_plainte_description']="Description de plainte/ Grief description";
$lang['ev_creation_plainte_description_action']="Description d'action requise / Action description required";
$lang['ev_creation_plainte_document_anx']="Document annexe à la plainte / Documents annex to the complaint";
$lang['ev_creation_plainte_historique']="Historique de la plainte / Complaint history";
$lang['ev_creation_plainte_date_heure']="Date et Heure / Date and time";
$lang['ev_creation_plainte_descr']="Description /  Description";
$lang['ev_creation_plainte_etat']="Etat / Status";
$lang['ev_creation_plainte_personn']="Personnel / Staff";

//creation plainte cloture

$lang['ev_creation_plainte_cloture_title']="::Bon de livraison / Delivery voucher";
$lang['ev_creation_plainte_cloture_plainte_resolu']="Plainte résolu. En attente du procès-verbal de cloture / Complaint resolved. Waiting for the closing minutes";









// configuration add

$lang['ev_persone_notifier_configue_add_title']=" Ajout d'un nouveaux profil";
$lang['ev_persone_notifier_configue_add_nom']=" Nom du profil";
$lang['ev_persone_notifier_configue_add_droit']=" A droit";
$lang['ev_persone_notifier_configue_add_visualiser']=" Visualisation des projets";
$lang['ev_persone_notifier_configue_add_cmp']=" Creation, Modification et supression des projets";
$lang['ev_persone_notifier_configue_add_visualisation_site']=" Visualisation des sites";
$lang['ev_persone_notifier_configue_add_cms']=" Creation, Modification et supression des sites";
$lang['ev_persone_notifier_configue_add_visualisation_entreprise']=" Visualisation des entreprises";
$lang['ev_persone_notifier_configue_add_cmse']=" Creation, Modification et supression des entreprises";
$lang['ev_persone_notifier_configue_visualisation_perso']=" Visualisation du personel";
$lang['ev_persone_notifier_configue_cmsp']=" Creation, Modification et supression du personel";
$lang['ev_persone_notifier_configue_visual_compos']=" Visualisation de la composition du site ";
$lang['ev_persone_notifier_configue_creation_site']=" Creation, Modification et supression de la composition du site";
$lang['ev_persone_notifier_configue_visual_plainte']=" Visualisation des plaintes";
$lang['ev_persone_notifier_configue_creation_plainte']=" Creation, Modification et supression des plaintes";
$lang['ev_persone_notifier_configue_cloture_plainte']=" Cloturer une plainte";
$lang['ev_persone_notifier_configue_controle_plainte']=" Tout le controle sur les plaintes ";
$lang['ev_persone_notifier_configue_personne_a_notifier']=" Visualisation des personnes a notifier";
$lang['ev_persone_notifier_configue_creation_a_notifier']=" Creation, Modification et supression des personnes a notifier";
$lang['ev_persone_notifier_configue_reporting']=" Reporting";
$lang['ev_persone_notifier_configue_monitoring']=" Monitoring";
$lang['ev_persone_notifier_configue_sms']=" SMS";
$lang['ev_persone_notifier_configue_configuration']=" Configuration";
$lang['ev_persone_notifier_configue_enregistrer']=" Enregistrer";

//configuration liste

$lang['ev_persone_notifier_configue_liste']=" Liste des Profils";


// configuration controller

$lang['ghi_persone_notifier_configue_contr_title']=" Creation du Profil fait avec succes";
$lang['ghi_persone_notifier_configue_contr_pro']="Profil";
$lang['ghi_persone_notifier_configue_contr_vprojet']="Voir les projets";
$lang['ghi_persone_notifier_configue_contr_oprojet']=" Operation sur les projets";
$lang['ghi_persone_notifier_configue_contr_vsite']=" Voir les sites";
$lang['ghi_persone_notifier_configue_contr_osite']=" Operation sur les Sites";
$lang['ghi_persone_notifier_configue_contr_ventrepr']="Voir les entreprises";
$lang['ghi_persone_notifier_configue_contr_oentrepr']=" Operation sur les entreprises";
$lang['ghi_persone_notifier_configue_contr_vperso']=" Voir le personel";
$lang['ghi_persone_notifier_configue_contr_operso']=" Operation sur le personel";
$lang['ghi_persone_notifier_configue_contr_vchantier']=" Voir la composition du chantier ";
$lang['ghi_persone_notifier_configue_contr_ochantier']=" Operation sur la composition du chantier";
$lang['ghi_persone_notifier_configue_contr_vplainte']=" Voir les plaintes";
$lang['ghi_persone_notifier_configue_contr_oplainte']=" Operation sur les plainte";
$lang['ghi_persone_notifier_configue_contr_cplainte']=" Cloturer une plainte";
$lang['ghi_persone_notifier_configue_contr_aplainte']=" Géstion de toutes les plaintes";
$lang['ghi_persone_notifier_configue_contr_pnotif']=" Personnel &agrave; notifier";
$lang['ghi_persone_notifier_configue_contr_opnotif']=" Operation sur Les personnels &agrave; notifier";
$lang['ghi_persone_notifier_configue_contr_report']=" Reporting";
$lang['ghi_persone_notifier_configue_contr_monitor']=" Monitoring";
$lang['gh_persone_notifier_configue_sms']=" SMS";
$lang['gh_persone_notifier_configue_configur']=" Configuration";
// $lang['gh_persone_notifier_configue_configur']=" Configuration";





// alerte plainte view
$lang['ghi_alert_plainte_view_projectid']=" Le projet du site doit être saisi";
$lang['ghi_alert_plainte_view_site_id']=" Le site doit être saisi";
$lang['ghi_alert_plainte_view_provinceid']=" La province de l\'incident doit être saisi";
$lang['ghi_alert_plainte_view_comuneid']=" La commune de l\'incident doit être saisi";
$lang['ghi_alert_plainte_view_dateid']=" La date de l\'incident doit être saisi";
$lang['ghi_alert_plainte_view_nomid']=" Nom du plaignant doit être saisi";
$lang['ghi_alert_plainte_view_phoneid']=" Une fois saisi le telephone du  plaignant doit être correct avec 8 chiffres";
$lang['ghi_alert_plainte_view_phoneiddeux']=" Le telephone du  plaignant doit être correct avec des chiffre";
$lang['ghi_alert_plainte_view_mail_co']=" Une fois saisi le mail du  plaignant doit être correct";
$lang['ghi_alert_plainte_view_coidentique']=" Vos deux mail ne sont pas identique";
$lang['ghi_alert_plainte_view_provinceidresi']=" La province de residences doit être saisi";
$lang['ghi_alert_plainte_view_comuneidresi']=" La commune de residences doit être saisi";
$lang['ghi_alert_plainte_view_canaltransmi']=" Le canal de transmision de la plainte doit être saisi";
$lang['ghi_alert_plainte_view_categorieplaint']=" La categorie de la plainte doit être saisi";
$lang['ghi_alert_plainte_view_infoplainte']=" Les Informations detaille de la plainte doivent être saisi";
$lang['ghi_alert_plainte_view_gestionplainte']=" La gestion de la plainte doit être saisi";
$lang['ghi_alert_plainte_view_verificationmail']=" Verification du E-mail";
$lang['ghi_alert_plainte_view_autreselect']=" Autre";
$lang['ghi_alert_plainte_view_entrenum']=" Enter le numero:";
$lang['ghi_alert_plainte_view_descriptionpetit']=" Une petite description:";
$lang['ghi_alert_plainte_view_refrerence']=" Enter la référence:";
$lang['ghi_alert_plainte_view_adressmail']=" Adress mail:";
$lang['ghi_alert_plainte_view_descriptionplainte']=" Description:";


$lang['site_crontrol_update_faill']="Le site existe";
$lang['personel_crontrol_update_fails']="L'entreprise existe";




$lang["datatable"]= json_encode(
        array(
            "sSearch"=>"Rechercher&nbsp;:",
            "oPaginate"=>array("sFirst"=>"Premier","sPrevious"=>"Pr&eacute;c&eacute;dent","sNext"=>"Suivant","sLast"=>"Dernier"),
            "sProcessing"=>"Traitement en cours...",
			"sLengthMenu"=>"Afficher _MENU_ &eacute;l&eacute;ments",
			"sInfo"=>"Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
			"sInfoEmpty"=>"Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
			"sInfoFiltered"=>"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
			"sInfoPostFix"=>"",
			"sLoadingRecords"=>"Chargement en cours...",
			"sZeroRecords"=>"Aucun &eacute;l&eacute;ment &agrave; afficher",
			"sEmptyTable"=>"Aucune donn&eacute;e disponible dans le tableau",
			"oAria"=>array("sSortAscending"=>": activer pour trier la colonne par ordre croissant",
									"sSortDescending"=> ": activer pour trier la colonne par ordre d&eacute;croissant")
            )
        );

//Landry//le 20/04/2018//creer un nouveau compte utilisateur

$lang["la_changer_mot_passe"]="Modifier le mot de passe";
$lang["la_pass_actuel"]="Mot de passe actuel";
$lang["la_nouveau_pass"]="Nouveau mot de passe";

$lang["la_confirm_pass"]="Confirmer le mot de passe";
$lang["la_pass_modifier"]="Changer le mot de passe";
$lang["la_mot_pass_success"]="Mot de passe modifié";

$lang["la_mot_incorrect"]="Le mot de passe actuel incorrect";
$lang["la_mot_incorrespond"]="Le nouveau mot de passe ne correspond pas a celui resaisi";














































































































//reporting
$lang['ev_persone_notifier_configue_reporting']=" Sélectionner";
















$lang['view_ihm_add_rh_btn']="Enregistrer";










