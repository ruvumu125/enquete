<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model{ 


	function create($table, $data) { 

        $query = $this->db->insert($table, $data);
        return ($query) ? true : false;

    }
    public function delete_files($file_name) {

        return $this->db->delete('photos', array('NOM_PHOTO' => $file_name));
    }
    function fetch_country()
 {
  $this->db->order_by("NOM_CATEGORIE", "ASC");
  $query = $this->db->get("categorie");
  return $query->result();
 }
 function fetch_actes()
 {
  $this->db->order_by("NOM_ACTE", "ASC");
  $query = $this->db->get("acte");
  return $query->result();
 }
 function fetch_grand_categorie()
 {
  $this->db->order_by("NOM_GRAND_CATEGORIE", "ASC");
  $query = $this->db->get("grand_categorie");
  return $query->result();
 }
 function fetch_province()
 {
  $this->db->order_by("NOM_PROVINCE", "ASC");
  $query = $this->db->get("province");
  return $query->result();
 }
  function fetch_commune()
 {
  $this->db->order_by("NOM_COMMUNE", "ASC");
  $query = $this->db->get("commune");
  return $query->result();
 }

 
 public function details_rapport($NUM_RAPPORT){ 

  $this->db->where('NUMERO_RAPPORT',$NUM_RAPPORT);
  $query = $this->db->get('rapport');
  $le_resultat=$query->row_array();

  //le montant total
  $total=$le_resultat['TOTAL'];
  //le montant total
  
  //le field officer
  $critero_field_officer['CODE_UTILISATEUR']=$le_resultat['CODE_UTILISATEUR'];
  $field_officer=$this->Model->getOne('utilisateur',$critero_field_officer);
  $nom_complet=$field_officer['NOM_UTILISATEUR'].' '.$field_officer['PRENOM_UTILISATEUR'];
  //le field officer
  
  //date de redaction
  $date=date("d-m-Y",strtotime($le_resultat['DATE']));
  $time=date("H:i:s",strtotime($le_resultat['DATE']));
  $display=' Le ' . $date.' à '.$time;
  //date de redaction

  $output = '<div class="form-group">';
  $output .= '<label>Redige par </label>';
  $output .= '<input type="text" name="" class="form-control" value="'.$nom_complet.'" disabled="">';
  $output .= '</div>';

  $output .= '<div class="form-group">';
  $output .= '<label>Date de redaction </label>';
  $output .= '<input type="text" name="" class="form-control" value="'.$display.'" disabled="">';
  $output .= '</div>';

  $output .= '<div class="form-group">';
  $output .= '<label>Montant total </label>';
  $output .= '<input type="text" name="" class="form-control" value="'.$total.'" disabled="">';
  $output .= '</div>';

  $output .= '<div class="form-group">';
  $output .= '<input type="hidden" name="montant_total" class="form-control" value="'.$total.'" >';
  $output .= '</div>';

  return $output;
 }

 public function taux_type_compte($CODE_TYPE_CREDIT){

  $this->db->where('CODE_TYPE_CREDIT',$CODE_TYPE_CREDIT);
  $query = $this->db->get('type_credit');
  $le_resultat=$query->row_array();

  $output = '<li>';
  $output .= '<div class="sf_columns column_2">';
  $output .= '<input type="hidden" name="taux_annuel" class="form-control"  value="'.$le_resultat['TAUX_INTERET_ANNUEL'].'" >';
  $output .= '</div>';
  $output .= '</li>';

  $output .= '<li>';
  $output .= '<div class="sf_columns column_2">';
  $output .= '<input type="hidden" name="taux_etude_dossier" class="form-control"  value="'.$le_resultat['FRAIS_ETUDE_DOSSIER'].'" >';
  $output .= '</div>';
  $output .= '</li>';

  return $output;


 }
 public function somme_epargne_entre($date_debut,$date_fin){

  $code_user=$this->session->userdata('CODE_UTIL');
  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_epargne_entre from transation where TYPE_TRANSATION='Épargne' AND date(DATE_TRANSATION) BETWEEN '$date_debut' AND '$date_fin' AND CODE_UTILISATEUR='$code_user' ");
  $resultats=$query_somme_epargne_today->row_array();
  //$somme=number_format($resultats['la_somme_epargne_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-yellow">';
  $output .= '<span class="info-box-icon"><i class="fa fa-money" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des épargnes entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_epargne_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';

  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 public function somme_retrait_entre($date_debut,$date_fin){

  $code_user=$this->session->userdata('CODE_UTIL');
  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_retrait_entre from transation where TYPE_TRANSATION='Retrait' AND date(DATE_TRANSATION) BETWEEN '$date_debut' AND '$date_fin' AND CODE_UTILISATEUR='$code_user' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_retrait_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-aqua">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des retraits entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_retrait_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 public function somme_epargne_entre_dashboard($date_debut,$date_fin){ 

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_epargne_entre from transation where TYPE_TRANSATION='Épargne' AND date(DATE_TRANSATION) BETWEEN '$date_debut' AND '$date_fin' ");
  $resultats=$query_somme_epargne_today->row_array();
  $somme=number_format($resultats['la_somme_epargne_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-yellow">';
  $output .= '<span class="info-box-icon"><i class="fa fa-money" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des épargnes entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_epargne_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 public function somme_retrait_entre_dashboard($date_debut,$date_fin){

  $code_user=$this->session->userdata('CODE_UTIL');
  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_epargne_entre from transation where TYPE_TRANSATION='Retrait' AND date(DATE_TRANSATION) BETWEEN '$date_debut' AND '$date_fin' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_epargne_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-aqua">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des retraits entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_epargne_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 public function somme_credit_entre_dashboard($date_debut,$date_fin){ 

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(CAPITAL) as la_somme_credit_entre from credit where date(DATE_OCTROI) BETWEEN '$date_debut' AND '$date_fin' ");
  $resultats=$query_somme_epargne_today->row_array();
  $somme=number_format($resultats['la_somme_credit_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-green">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des crédit entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_credit_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }

 public function somme_interet_entre_dashboard($date_debut,$date_fin){

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(INTERET) as la_somme_interet_entre from tranches_credit where date(DATE_PAIEMENT) BETWEEN '$date_debut' AND '$date_fin' AND REMBOURSE='1' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_interet_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-aqua">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme des intérêts entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_interet_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }

 public function somme_frais_dossier_entre_dashboard($date_debut,$date_fin){

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_frais_dossier_entre from  income_frais_dossier_credit where date(DATE) BETWEEN '$date_debut' AND '$date_fin' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_frais_dossier_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-yellow">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme frais du dossier entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_frais_dossier_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 public function somme_tenue_compte_entre_dashboard($date_debut,$date_fin){

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_tenue_compte_entre from income where date(DATE) BETWEEN '$date_debut' AND '$date_fin' AND MOTIF='Frais de tenue de compte' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_tenue_compte_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-red">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme tenue de compte entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_tenue_compte_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }
 
 public function somme_achat_carnet($date_debut,$date_fin){

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_carnet_entre from  income where date(DATE) BETWEEN '$date_debut' AND '$date_fin' AND   MOTIF='Frais d’achat de carnet du sociétaire' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_carnet_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-green">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme frais du dossier entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_carnet_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }

 public function ouverture_compte($date_debut,$date_fin){

  $date_debito=date("d-m-Y",strtotime($date_debut));
  $date_fino=date("d-m-Y",strtotime($date_fin));

  $query_somme_epargne_today = $this->db->query("select sum(MONTANT) as la_somme_ouverture_entre from income where date(DATE) BETWEEN '$date_debut' AND '$date_fin' AND MOTIF='Frais d’ouverture de compte' ");
  $resultats=$query_somme_epargne_today->row_array();

  $somme=number_format($resultats['la_somme_ouverture_entre'], 0, ',', ' ');

  $output = '<div class="info-box bg-yellow">';
  $output .= '<span class="info-box-icon"><i class="fa fa-eur" style="margin-top: 20px;"></i></span>';
  $output .= '<div class="info-box-content">';
  $output .= '<span class="info-box-text">Somme tenue de compte entre <b>'.$date_debito.' et '.$date_fino.'</b></span>';

  if ($resultats['la_somme_ouverture_entre']==NULL):
  $output .= '<span class="info-box-number">0</span>';
  else:
  $output .= '<span class="info-box-number">'.$somme.'</span>';
  endif;

  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
 }

 public function details_societaire($CODE_SOCIETAIRE)
 {

  $this->db->where('CODE_SOCIETAIRE',$CODE_SOCIETAIRE);
  $query = $this->db->get('societaire');
  $le_resultat=$query->row_array();

  //province 
  $crit_province_residence['CODE_PROVINCE']=$le_resultat['PROVINCE'];
  $province=$this->Model->getOne('province',$crit_province_residence);
  //province

  //commune
  $crit_commune_residence['CODE_COMMUNE']=$le_resultat['COMMUNE'];
  $commune=$this->Model->getOne('commune',$crit_commune_residence);
  //commune

  //zone
  $crit_zone_residence['CODE_ZONE']=$le_resultat['ZONE'];
  $zone=$this->Model->getOne('zone',$crit_zone_residence);
  //zone


  //colline
  $crit_colline_residence['CODE_COLLINE']=$le_resultat['COLLINE'];
  $colline=$this->Model->getOne('colline',$crit_colline_residence);
  //colline

  //sous_colline
  $crit_sous_colline['CODE_SOUS_COLLINE']=$le_resultat['SOUS_COLLINE'];
  $sous_colline=$this->Model->getOne('sous_colline',$crit_sous_colline); 
  //sous_colline
  

  $output = '<div class="box box-primary" style="border-left: 1px solid #ecf0f5;border-right: 1px solid #ecf0f5;border-bottom: 1px solid #ecf0f5;">';
  $output .= '<div class="box-header with-border">';
  $output .= '<h3 class="box-title"> Détails du sociétaire</h3>'; 
  $output .= '</div>';
  $output .= '<div class="box-body">';
  $output .= '<div class="col-md-12">';

  //photo  
  $output .= '<div class="">';
  $output .= '<div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden">';
  $output .= '<div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">';

  if(!empty($le_resultat['PHOTO'])):
  $output .= '<img src=" '. base_url('uploads/societaire/') .$le_resultat['PHOTO'].' " alt="">';
  else:
  $output .= '<img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="">';
  endif;

  $output .= '</div>';
  $output .= '<div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"></div>';
  $output .= '</div>';
  $output .= '</div>';
  //photo


  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Nom de famille </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$le_resultat['NOM_FAMILLE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';


  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Prénom </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$le_resultat['PRENOM'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Province de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$province['NOM_PROVINCE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Commune de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$commune['NOM_COMMUNE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Zone de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$zone['NOM_ZONE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$colline['NOM_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Sous-colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$sous_colline['NOM_SOUS_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Numéro de la CNI </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$le_resultat['NUM_CNI'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
 
  $output .= '<input class="form-control" type="hidden" required="required" name="nom_du_socetaire" id="LabRefNo" value="'.$le_resultat['NOM_FAMILLE'].'">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  
  $output .= '<input class="form-control" type="hidden" required="required" name="prenom_du_socetaire" id="LabRefNo" value="'.$le_resultat['PRENOM'].'">';
  $output .= '</div>';
  $output .= '</div>';



  $output .= '</div>';
  $output .= '</div>';
  $output .= '</div>';
  
  return $output;


 }

 public function details_societaire_transation($NUM_COMPTE)
 {

  $this->db->where('NUM_COMPTE',$NUM_COMPTE);
  $query = $this->db->get('compte');
  $le_resultat=$query->row_array();

  //variables globales
  $nom_famille;
  $prenom;
  $province;
  $commune;
  $zone;
  $colline;
  $sous_colline;
  $num_cni;
  //variables globales

  //type compte
  $crit_type['CODE_TYPE_COMPTE']=$le_resultat['CODE_TYPE_COMPTE'];
  $type_compte=$this->Model->getOne('type_compte',$crit_type);
  //type compte

  if ($type_compte['TYPE_COMPTE']=="Compte primaire") {

    $critere_comp_prim['NUM_COMPTE']=$le_resultat['NUM_COMPTE'];
    $le_compte_primaire=$this->Model->getOne('compte_primaire',$critere_comp_prim);
    $critere_societero['CODE_SOCIETAIRE']=$le_compte_primaire['CODE_SOCIETAIRE'];
    $le_societaire=$this->Model->getOne('societaire',$critere_societero);
    
    $nom_famille=$le_societaire['NOM_FAMILLE'];
    $prenom=$le_societaire['PRENOM'];
    $num_cni=$le_societaire['NUM_CNI'];

    //province 
    $crit_province_residence['CODE_PROVINCE']=$le_societaire['PROVINCE'];
    $province=$this->Model->getOne('province',$crit_province_residence);
    //province

    //commune
    $crit_commune_residence['CODE_COMMUNE']=$le_societaire['COMMUNE'];
    $commune=$this->Model->getOne('commune',$crit_commune_residence);
    //commune

    //zone
    $crit_zone_residence['CODE_ZONE']=$le_societaire['ZONE'];
    $zone=$this->Model->getOne('zone',$crit_zone_residence);
    //zone


    //colline
    $crit_colline_residence['CODE_COLLINE']=$le_societaire['COLLINE'];
    $colline=$this->Model->getOne('colline',$crit_colline_residence);
    //colline

    //sous_colline
    $crit_sous_colline['CODE_SOUS_COLLINE']=$le_societaire['SOUS_COLLINE'];
    $sous_colline=$this->Model->getOne('sous_colline',$crit_sous_colline);
    //sous_colline

    $output = '<div class="box box-primary" style="border-left: 1px solid #ecf0f5;border-right: 1px solid #ecf0f5;border-bottom: 1px solid #ecf0f5;">';
  $output .= '<div class="box-header with-border">';
  $output .= '<h3 class="box-title"> Détails de la propriétaire du compte</h3>';
  $output .= '</div>';
  $output .= '<div class="box-body">';
  $output .= '<div class="col-md-12">';

   //photo  
  $output .= '<div class="">';
  $output .= '<div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden">';
  $output .= '<div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">';

  if(!empty($le_societaire['PHOTO'])):
  $output .= '<img src=" '. base_url('uploads/societaire/') .$le_societaire['PHOTO'].' " alt="">';
  else:
  $output .= '<img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="">';
  endif;

  $output .= '</div>';
  $output .= '<div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"></div>';
  $output .= '</div>';
  $output .= '</div>';
  //photo

  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Nom de famille </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$nom_famille.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Prénom </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$prenom.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Province de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$province['NOM_PROVINCE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Commune de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$commune['NOM_COMMUNE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Zone de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$zone['NOM_ZONE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$colline['NOM_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Sous-colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$sous_colline['NOM_SOUS_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Numéro de la CNI </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$num_cni.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
 
  $output .= '<input class="form-control" type="hidden" required="required" name="nom_du_socetaire" id="LabRefNo" value="'.$nom_famille.'">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  
  $output .= '<input class="form-control" type="hidden" required="required" name="prenom_du_socetaire" id="LabRefNo" value="'.$prenom.'">';
  $output .= '</div>';
  $output .= '</div>';



  $output .= '</div>';
  $output .= '</div>';
  $output .= '</div>';
  
  return $output;

  }
  elseif ($type_compte['TYPE_COMPTE']=="Compte de groupement") {
    
    $critere_comp_group['NUM_COMPTE']=$le_resultat['NUM_COMPTE'];
    $le_compte_groupement=$this->Model->getList('compte_groupement_societaire',$critere_comp_group);

    $nos_data=array();

    foreach ($le_compte_groupement as $group) {
      
      $critere_societero['CODE_SOCIETAIRE']=$group['CODE_SOCIETAIRE'];
      $le_societaire=$this->Model->getOne('societaire',$critere_societero);

      $nom_famille=$le_societaire['NOM_FAMILLE'];
      $prenom=$le_societaire['PRENOM'];
      $num_cni=$le_societaire['NUM_CNI'];

      //province 
      $crit_province_residence['CODE_PROVINCE']=$le_societaire['PROVINCE'];
      $province=$this->Model->getOne('province',$crit_province_residence);
      //province

      //commune
      $crit_commune_residence['CODE_COMMUNE']=$le_societaire['COMMUNE'];
      $commune=$this->Model->getOne('commune',$crit_commune_residence);
      //commune

      //zone
      $crit_zone_residence['CODE_ZONE']=$le_societaire['ZONE'];
      $zone=$this->Model->getOne('zone',$crit_zone_residence);
      //zone

      //colline
      $crit_colline_residence['CODE_COLLINE']=$le_societaire['COLLINE'];
      $colline=$this->Model->getOne('colline',$crit_colline_residence);
      //colline

      //sous_colline
      $crit_sous_colline['CODE_SOUS_COLLINE']=$le_societaire['SOUS_COLLINE'];
      $sous_colline=$this->Model->getOne('sous_colline',$crit_sous_colline);
      //sous_colline

      $nos_data[]=array(

        'nom'=>$nom_famille,
        'prenom'=>$prenom,
        'colline'=>$colline['NOM_COLLINE'],
        'sous_colline'=>$sous_colline['NOM_SOUS_COLLINE'],
        'cni'=>$num_cni

      );

    }
    $list=$nos_data;
    $templates=array(
         'table_open' => '<table class="table table-bordered table-stripped table-hover table-condensed" id="table_id"> ',
         'table_close'  => '</table>');
          $this->table->set_heading(array('Nom','Prénom','Colline','Sous-colline','Nº CNI'));

          $this->table->set_template($templates);
    
    $output = '<div class="box box-primary" style="border-left: 1px solid #ecf0f5;border-right: 1px solid #ecf0f5;border-bottom: 1px solid #ecf0f5;">';
    $output .= '<div class="box-header with-border">';
    $output .= '<h3 class="box-title"> Liste des propriétaires du compte</h3>';
    $output .= '</div>';
    $output .= '<div class="box-body">';
    $output .=$this->table->generate($list);
    $output .= '</div>';
    $output .= '</div>';
    return $output;
    


  }
  elseif ($type_compte['TYPE_COMPTE']=="Compte individuel") {

    $critere_comp_indiv['NUM_COMPTE']=$le_resultat['NUM_COMPTE'];
    $le_compte_individuel=$this->Model->getOne('compte_individuel',$critere_comp_indiv);
    $critere_societero['CODE_SOCIETAIRE']=$le_compte_individuel['CODE_SOCIETAIRE'];
    $le_societaire=$this->Model->getOne('societaire',$critere_societero);
    
    $nom_famille=$le_societaire['NOM_FAMILLE'];
    $prenom=$le_societaire['PRENOM'];
    $num_cni=$le_societaire['NUM_CNI'];

    //province 
    $crit_province_residence['CODE_PROVINCE']=$le_societaire['PROVINCE'];
    $province=$this->Model->getOne('province',$crit_province_residence);
    //province

    //commune
    $crit_commune_residence['CODE_COMMUNE']=$le_societaire['COMMUNE'];
    $commune=$this->Model->getOne('commune',$crit_commune_residence);
    //commune

    //zone
    $crit_zone_residence['CODE_ZONE']=$le_societaire['ZONE'];
    $zone=$this->Model->getOne('zone',$crit_zone_residence);
    //zone


    //colline
    $crit_colline_residence['CODE_COLLINE']=$le_societaire['COLLINE'];
    $colline=$this->Model->getOne('colline',$crit_colline_residence);
    //colline

    //sous_colline
    $crit_sous_colline['CODE_SOUS_COLLINE']=$le_societaire['SOUS_COLLINE'];
    $sous_colline=$this->Model->getOne('sous_colline',$crit_sous_colline);
    //sous_colline

    $output = '<div class="box box-primary" style="border-left: 1px solid #ecf0f5;border-right: 1px solid #ecf0f5;border-bottom: 1px solid #ecf0f5;">';
  $output .= '<div class="box-header with-border">';
  $output .= '<h3 class="box-title"> Détails de la propriétaire du compte</h3>';
  $output .= '</div>';
  $output .= '<div class="box-body">';
  $output .= '<div class="col-md-12">';

  //photo  
  $output .= '<div class="">';
  $output .= '<div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden">';
  $output .= '<div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">';

  if(!empty($le_societaire['PHOTO'])):
  $output .= '<img src=" '. base_url('uploads/societaire/') .$le_societaire['PHOTO'].' " alt="">';
  else:
  $output .= '<img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="">';
  endif;

  $output .= '</div>';
  $output .= '<div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 10px;"></div>';
  $output .= '</div>';
  $output .= '</div>';
  //photo

  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Nom de famille </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$nom_famille.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Prénom </label>';
  $output .= '<input class="form-control" type="text" required="required" name="" id="LabRefNo" value="'.$prenom.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Province de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$province['NOM_PROVINCE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Commune de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$commune['NOM_COMMUNE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Zone de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$zone['NOM_ZONE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$colline['NOM_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';
  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
  $output .= '<label>Sous-colline de résidence </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$sous_colline['NOM_SOUS_COLLINE'].'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  $output .= '<label>Numéro de la CNI </label>';
  $output .= '<input class="form-control" type="text" required="required" name="LabRefNo" id="LabRefNo" value="'.$num_cni.'" disabled="">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6 row">';
  $output .= '<div class="form-group">';
 
  $output .= '<input class="form-control" type="hidden" required="required" name="nom_du_socetaire" id="LabRefNo" value="'.$nom_famille.'">';
  $output .= '</div>';
  $output .= '</div>';

  $output .= '<div class="col-md-6">';
  $output .= '<div class="form-group">';
  
  $output .= '<input class="form-control" type="hidden" required="required" name="prenom_du_socetaire" id="LabRefNo" value="'.$prenom.'">';
  $output .= '</div>';
  $output .= '</div>';



  $output .= '</div>';
  $output .= '</div>';
  $output .= '</div>';
  
  return $output;
  
  }


 }

 function fetch_province_one($CODE_PROVINCE)
 {
  $this->db->where('CODE_PROVINCE', $CODE_PROVINCE);
  $this->db->order_by('NOM_COMMUNE', 'ASC');
  $query = $this->db->get('commune');
  $output = '<option value="">Selectionner la commune ...</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_COMMUNE.'">'.$row->NOM_COMMUNE.'</option>';
  }
  return $output;
 }
 function fetch_commune_one($CODE_COMMUNE)
 {
  $this->db->where('CODE_COMMUNE', $CODE_COMMUNE);
  $this->db->order_by('NOM_ZONE', 'ASC');
  $query = $this->db->get('zone');
  $output = '<option value="">Selectionner la zone ...</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_ZONE.'">'.$row->NOM_ZONE.'</option>';
  }
  return $output;
 }
 function fetch_zone_one($CODE_ZONE)
 {
  $this->db->where('CODE_ZONE', $CODE_ZONE);
  $this->db->order_by('NOM_COLLINE', 'ASC');
  $query = $this->db->get('colline');
  $output = '<option value="">Selectionner la colline ...</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_COLLINE.'">'.$row->NOM_COLLINE.'</option>';
  }
  return $output;
 }
 function fetch_sous_colline_one($CODE_COLLINE)
 {
  $this->db->where('CODE_COLLINE', $CODE_COLLINE);
  $this->db->order_by('NOM_SOUS_COLLINE', 'ASC');
  $query = $this->db->get('sous_colline');
  $output = '<option value="">Selectionner la sous-colline ...</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_SOUS_COLLINE.'">'.$row->NOM_SOUS_COLLINE.'</option>';
  }
  return $output;
 }

 function fetch_stateu($CODE_ACTE)
 {
  $this->db->select('*');
  $this->db->from('acte');
  $this->db->join('service', 'acte.CODE_SERVICE = service.CODE_SERVICE');
  $this->db->where('CODE_ACTE', $CODE_ACTE);
  $query = $this->db->get();
  $temp=$query->row_array();
  echo $temp['NOM_SERVICE'];
  
 }

   //bien
  function fetch_state($CODE_CATEGORIE)
 {
  $this->db->where('CODE_CATEGORIE', $CODE_CATEGORIE);
  $this->db->order_by('NOM_SOUS_CATEGORIE', 'ASC');
  $query = $this->db->get('sous_categorie');
  $output = '<option value="">--- Selectionner la sous-catégorie ---</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_SOUS_CATEGORIE.'">'.$row->NOM_SOUS_CATEGORIE.'</option>';
  }
  return $output;
 }
 function fetch_state_one($CODE_CATEGORIE)
 {
    $this->db->where('CODE_CATEGORIE', $CODE_CATEGORIE);
    $query = $this->db->get('sous_categorie');
    $res=$query->row_array();
    $output='<option value="'.$res['CODE_SOUS_CATEGORIE'].'">'.$res['NOM_SOUS_CATEGORIE'].'</option>';
    return $output;
 }
 function fetch_categorie($CODE_GRAND_CATEGORIE)
 {
  $this->db->where('CODE_GRAND_CATEGORIE', $CODE_GRAND_CATEGORIE);
  $this->db->order_by('NOM_CATEGORIE', 'ASC');
  $query = $this->db->get('categorie');
  $output = '<option value="">--- Selectionner la catégorie ---</option>';
  foreach($query->result() as $row)
  {
   $output .= '<option value="'.$row->CODE_CATEGORIE.'">'.$row->NOM_CATEGORIE.'</option>';
  }
  return $output;
 }
 function fetch_categorie_one($CODE_CATEGORIE)
 {
    $this->db->where('CODE_GRAND_CATEGORIE',$CODE_GRAND_CATEGORIE);
    $query = $this->db->get('categorie');
    $res=$query->row_array();
    $output='<option value="'.$res['CODE_CATEGORIE'].'">'.$res['NOM_CATEGORIE'].'</option>';
    return $output;
 }
 //Fin bien

  function save_visiteur(){
    $code_visiteur=uniqid();
    $data_visiteur = array(
        'NOM_VISITEUR'  => $this->input->post('NOM_VISITEUR'), 
        'EMAIL_VISITEUR'  => $this->input->post('EMAIL_VISITEUR'), 
        'CODE_VISITEUR' => $code_visiteur, 
      );
    $data_commentaire = array(

        'ARTICLE_SLUG'=>$this->input->post('CODE_ARTICLE'),
        'CODE_VISITEUR'=>$code_visiteur,
        'CONTENU_COMMENT'=>$this->input->post('CONTENU_COMMENT'),
        'DATE'=>date('Y-m-d H:i:s') 
      );
    $result=array();
    $result=$this->db->insert('visiteur',$data_visiteur);
    $result=$this->db->insert('commentaire_visiteur',$data_commentaire);
    return $result;
  }
  function update_statut(){


       //$selected_courses=$this->input->post('selected_courses');
       $CODE_PUBLICITE=$this->input->post('CODE_PUBLICITE');
       $STATUT_PUB='1';

       $this->db->set('STATUT_PUB', $STATUT_PUB);
       $this->db->where('CODE_PUBLICITE', $CODE_PUBLICITE);
       $result=$this->db->update('publicite');
       return $result;
        
  }
  function desactiver_statut(){


       //$selected_courses=$this->input->post('selected_courses');
       $CODE_PUBLICITE=$this->input->post('CODE_PUBLICITE');
       $STATUT_PUB='0';

       $this->db->set('STATUT_PUB', $STATUT_PUB);
       $this->db->where('CODE_PUBLICITE', $CODE_PUBLICITE);
       $result=$this->db->update('publicite');
       return $result;
        
  }
  function update_statut_comment(){


       //$selected_courses=$this->input->post('selected_courses');
       $CODE_VISITEUR=$this->input->post('CODE_VISITEUR');
       $STATUT_COMMENT='1';

       $this->db->set('STATUT_COMMENT',$STATUT_COMMENT);
       $this->db->where('CODE_VISITEUR', $CODE_VISITEUR);
       $result=$this->db->update('commentaire_visiteur');
       return $result;
        
  }
  function desactiver_statut_comment(){

   //$selected_courses=$this->input->post('selected_courses');
       $CODE_VISITEUR=$this->input->post('CODE_VISITEUR');
       $STATUT_COMMENT='0';

       $this->db->set('STATUT_COMMENT',$STATUT_COMMENT);
       $this->db->where('CODE_VISITEUR', $CODE_VISITEUR);
       $result=$this->db->update('commentaire_visiteur');
       return $result;
        
  }
  function update_counter($slug) {
// return current article views 
    $this->db->where('CODE_ARTICLE', urldecode($slug));
    $this->db->select('ARTICLE_VIEWS');
    $count = $this->db->get('article')->row();
// then increase by one 
    $this->db->where('CODE_ARTICLE', urldecode($slug));
    $this->db->set('ARTICLE_VIEWS', ($count->ARTICLE_VIEWS + 1));
    $this->db->update('article');
}
    
    function getCityDepartment($postData){
    $response = array();
 
    // Select record
    $this->db->select('CODE_SOUS_CATEGORIE,NOM_SOUS_CATEGORIE');
    $this->db->where('CODE_CATEGORIE', $postData['city']);
    $q = $this->db->get('sous_categorie');
    $response = $q->result_array();

    return $response;
  }
    function insert_batch($table,$data){
      
    $query=$this->db->insert_batch($table, $data);
    return ($query) ? true : false;
    //return ($query)? true:false;

    }
     function update_batch1($table,$data,$criteres){
     // $this->db->where($criteres);
    $query=$this->db->update_batch($table, $data,$criteres);
    return ($query) ? true : false;
    //return ($query)? true:false;

    }
    function update_product(){
        $product_code=$this->input->post('product_code');
        $product_name=$this->input->post('product_name');
        
 
        $this->db->set('EST_MEUBLE', $product_name);
       
        $this->db->where('CODE_LOGEMENT', $product_code);
        $result=$this->db->update('logement');
        return $result;
    }
    public function fetch_data_pagination($limit,$start,$critere = array()) {
      
      $query = $this->db->query("select NOM_CATEGORIE,DATE_PUBLICATION,IMAGE_PRINCIPALE,TITRE_ARTICLE,ARTICLE_SLUG from article,categorie, article_ecrit where TYPE_ARTICLE='Contenus web' AND article_ecrit.CODE_ARTICLE=article.CODE_ARTICLE AND article.CODE_CATEGORIE=categorie.CODE_CATEGORIE AND categorie.NOM_CATEGORIE='$critere' ORDER BY DATE_PUBLICATION DESC limit $limit,$start");
      return $query->result_array();
    }
//select * from article where CODE_GRAND_CATEGORIE='$critero_code_categorie'
    function pagination($table,$limit, $start,$criteres=array()){
       
       $this->db->select('*');
       $this->db->from($table);
       $this->db->where($criteres);
       $this->db->limit($limit, $start);
       $query = $this->db->get();

       if ($query->num_rows() > 0) {
 
           foreach ($query->result_array() as $row) {
 
               $data[] = $row;
 
           }
 
           return $data;
 
       }
 
       return false;

    }
    function pagination_tous($limit, $start,$criteres=array()){
       
       $this->db->select('*');
       $this->db->from('article');
       $this->db->join('categorie', 'categorie.CODE_CATEGORIE = article.CODE_CATEGORIE');
       $this->db->join('article_ecrit', 'article.CODE_ARTICLE = article_ecrit.CODE_ARTICLE');
       $this->db->join('pays', 'article.id_pays=pays.id_pays');
       $this->db->join('utilisateur', 'article.CODE_UTILISATEUR=utilisateur.CODE_UTILISATEUR');
       $this->db->order_by("DATE_PUBLICATION", "DESC");
       $this->db->where($criteres);
       $this->db->limit($limit, $start);
       $query = $this->db->get();

       if ($query->num_rows() > 0) {
 
           foreach ($query->result_array() as $row) {
 
               $data[] = $row;
 
           }
 
           return $data;
 
       }
 
       return false;

    }

    function getListLimit($table,$limit)
    {
     $this->db->limit($limit);
     $query= $this->db->get($table);
     
      if($query)
       {
           return $query->result_array();
       }   
    }

    function getnotin(){
      
      $noms=array('Poritique','Ubutunzi','Inkino','Imyidagaduro','Akazi','Buruse','Umutekano','Kumenyekanisha','Ukwamamaza');
      $this->db->select("*");
      $this->db->from('categorie');
      $this->db->where_not_in('NOM_CATEGORIE', $noms);
      $query = $this->db->get();
      return $query->result_array();
    }

    function getListLimitwhere($table,$criteres = array(),$limit)
    {
      $this->db->limit($limit);
      $this->db->where($criteres);
     $query= $this->db->get($table);
     
      if($query)
       {
           return $query->result_array();
       }   
    }



    function getList_distinct($table,$distinct=array()) {
        $this->db->select($distinct);
        $this->db->distinct();
        $query = $this->db->get($table);
        return $query->result_array();
    }
    function getList_between($table,$critere=array(),$criteres=array()){
        $this->db->where('NBRE_PIECES_PRINCIPALES >=', $critere);
$this->db->where('NBRE_PIECES_PRINCIPALES <=', $criteres);
return $this->db->get($table);
    }

  function update($table, $criteres, $data) {
        $this->db->where($criteres);
        $query = $this->db->update($table, $data);
        return ($query) ? true : false;
    }
    function update_batch($table, $criteres, $data) {
        $this->db->where($criteres);
        $query = $this->db->update_batch($table, $data);
        return ($query) ? true : false;
    }
  function update_table($table, $criteres, $data) {
        foreach ($data as $key => $value) {
          $this->db->set($key,$value);
        }
        $this->db->where($criteres);
        $query = $this->db->update($table);
        return ($query) ? true : false;
    }  

    function insert_last_id($table, $data) {

        $query = $this->db->insert($table, $data);
       
       if ($query) {
            return $this->db->insert_id();
        }

    }

       


    function getList($table,$criteres = array()) { 
        $this->db->where($criteres);
        $query = $this->db->get($table);
        return $query->result_array();
    }
    function getListNotin($table,$champs,$tableau = array()) {
        $this->db->where_not_in($champs,$tableau);
        $query = $this->db->get($table);
        return $query->result_array();
    }
    function getOneNotin($table,$champs,$tableau = array()) {
        $this->db->where_not_in($champs,$tableau);
        $query = $this->db->get($table);
        return $query->row_array();
    }


    function getListOrdertwo($table,$criteres = array(),$order) {
        $this->db->order_by($order);
        $this->db->where($criteres);
        
        $query = $this->db->get($table);
        return $query->result_array();
    }


    function checkvalue($table, $criteres) {
        $this->db->where($criteres);
        $query = $this->db->get($table);
        if($query->num_rows() > 0)
        {
           return true ;
        }
        else{
    return false;
    }
    }



    function getOne($table, $criteres) {
        $this->db->where($criteres);
        $query = $this->db->get($table);
        return $query->row_array();
    }

   function delete($table,$criteres){
        $this->db->where($criteres);
        $query = $this->db->delete($table);
        return ($query) ? true : false;
    }



    function record_count($table)
    {
       $query= $this->db->get($table);
       if($query)
       {
           return $query->num_rows();
       }
       
    }


    function record_countsome($table, $criteres)
    {
      $this->db->where($criteres);
       $query= $this->db->get($table);
       if($query)
       {
           return $query->num_rows();
       }
       
    }



        function getListOrder($table,$criteres)
    {
        $this->db->order_by($criteres);
      $query= $this->db->get($table);
      if($query)
      {
          return $query->result_array();
      }
    }
	



     function fetch_table($table,$limit,$start,$order,$ordervalue)
    {
     $this->db->limit($limit,$start);
     $this->db->order_by($order,$ordervalue);
     $query= $this->db->get($table);
     
      if($query)
       {
           return $query->result_array();
       }   
    }




        function getToutList($requete) {
        //$this->db->where($criteres);
       $query = $this->db->query($requete);
       $result=$query->result_array();
        return $result;
    }
    
    function checkvalue1($table,$champ, $criteres) {
        
        $this->db->where($champ, $criteres);
        $query = $this->db->get($table);

        if ($query) {
            return $query->row_array();
        }
       
    }

    public function Listdelegationpersonnel(){
    $data = array();
    $this->db->select('pd.ID_DELEGATION');
    
    $this->db->from('personnel_delegation pd');

    $this->db->group_by('pd.ID_DELEGATION');
    $query=$this->db->get();
       
    if ($query) {
            return $query->result_array();
        }
    }

    function ListOrder_personnel($table,$condition= array(),$criteres)
    {
        $this->db->where($condition);
        $this->db->order_by($criteres);
      $query= $this->db->get($table);
      if($query)
      {
          return $query->result_array();
      }
    }

public function get_elements($criterepieces=array()){

      /* $this->db->select('NOM_ELEMENT');
       
      $this->db->group_by('NOM_ELEMENT');
      $query=$this->db->get($table);
      return $query->result_array()  ;*/
      
  $this->db->select("*");
  $this->db->from('element e');
  $this->db->join('elements_piece ep', 'ep.CODE_ELEMENT = e.CODE_ELEMENT');
   $this->db->where("CODE_PIECE",$criterepieces);
  $query = $this->db->get();
  return $query->result_array();
 
       }
    public function get_ones($table, $champ, $value) {
        $this->db->where($champ, $value);
        $query = $this->db->get($table);
        if ($query) {
            return $query->result_array();
        }
    }

//fonction ghislain
function getList_distinct_some($table,$distinct=array(), $value) {
        $this->db->where($value);
        $this->db->select($distinct);
        $query = $this->db->get($table);
        return $query->result_array();
    }


function fetch_table_new($table,$limit,$start,$order,$ordervalue,$criteres)
    {
     $this->db->where($criteres);
     $this->db->limit($limit,$start);
     $this->db->order_by($order,$ordervalue);
     $query= $this->db->get($table);
     
      if($query)
       {
           return $query->row_array();
       }   
    }



    //fonction permettant de se connecter
function login($email,$password)
    {
   $this->db->where('EMAIL_PRENEUR',$email);
   $this->db->where('PASSWORD',$password);
   $query=$this->db->get('preneur');

  if($query->num_rows()==1)
   {
      return $query->row();
    }
  else{
      return false;
      }
   }


   function getListOrdered($table,$order=array(),$criteres = array()) {
        $this->db->where($criteres);
        $this->db->order_by($order,"ASC");
        $query = $this->db->get($table);
        return $query->result_array();
    }
    function getListOrdered_desc($table,$order=array(),$criteres = array()) {
        $this->db->where($criteres);
        $this->db->order_by($order,"DESC");
        $query = $this->db->get($table);
        return $query->result_array();
    }

    function record_countsome22($table, $criteres=array(),$cond=array())
    {
      $this->db->where($criteres);
      $this->db->where($cond);
       $query= $this->db->get($table);
       if($query)
       {
           return $query->num_rows();
       }
       
    }

  public function getRecord_grande_cat($marques=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
  {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('grand_categorie', 'grand_categorie.CODE_GRAND_CATEGORIE= article.CODE_GRAND_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE', $marques);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    $query = $this->db->get();
    return $query->result_array();
  }
  public function getRecordCount_grand_cat($criteres=array())
  {
      $this->db->select('count(*) as allcount');
      $this->db->from('article');
      $this->db->where($criteres);
      $query = $this->db->get();
      $result = $query->result_array();      
      return $result[0]['allcount'];
  }
  public function getRecordCount_categorie($criteres=array())
  {
      $this->db->select('count(*) as allcount');
      $this->db->from('article');
      $this->db->where($criteres);
      $query = $this->db->get();
      $result = $query->result_array();      
      return $result[0]['allcount'];
  }

  public function getRecord_vetements($marques=array(),$tailles=array(),$occasion=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
    {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('article_vetements_adulte', 'article_vetements_adulte.CODE_ARTICLE= article.CODE_ARTICLE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if($tailles !=''){
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($occasion !=''){
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    $query = $this->db->get();
    return $query->result_array();
  }
  public function getRecord_chaussures($marques=array(),$tailles=array(),$occasion=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
    {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('article_chaussures', 'article_chaussures.CODE_ARTICLE= article.CODE_ARTICLE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if($tailles !=''){
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($occasion !=''){
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE', $tailles);
      $this->db->where_in('OCCASION',$occasion);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    $query = $this->db->get();
    return $query->result_array();
  }

  public function getRecord_ordi($marques=array(),$tailles_ordi=array(),$processeur=array(),$systeme=array(),$disque=array(),$ram_ordi=array(),$ecran_ordi=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
    {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('article_ordinateur', 'article_ordinateur.CODE_ARTICLE= article.CODE_ARTICLE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if($tailles_ordi !=''){

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($processeur !=''){
      
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($systeme != '') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($disque != '') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($ram_ordi != '') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($ecran_ordi != '') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_ECRAN',$tailles_ordi);
      $this->db->where_in('PROCESSEUR',$processeur);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('DISQUE_DUR',$disque);
      $this->db->where_in('RAM',$ram_ordi);
      $this->db->where_in('ECRAN',$ecran_ordi);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    $query = $this->db->get();
    return $query->result_array();
  }
  public function getRecord_telephonie($marques=array(),$taille_ecran=array(),$reseau=array(),$nb_sim=array(),$memoire_interne=array(),$memoire_ram=array(),$cam_avant=array(),$cam_arriere=array(),$systeme=array(),$batter_amovible=array(),$capacite_batt=array(),$ecran_tactile=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
    {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('article_telephonie', 'article_telephonie.CODE_ARTICLE= article.CODE_ARTICLE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($taille_ecran != '') {

      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($reseau != '') {

      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($nb_sim != '') {

      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($memoire_interne != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($memoire_ram != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($cam_arriere != '') {

      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($cam_avant != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($systeme != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($batter_amovible != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($capacite_batt != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    elseif ($ecran_tactile != '') {
      
      $this->db->where_in('MARQUE',$marques);
      $this->db->where_in('TAILLE_ECRAN',$taille_ecran);
      $this->db->where_in('RESEAU',$reseau);
      $this->db->where_in('NBRE_SIM',$nb_sim);
      $this->db->where_in('MEMOIRE_INTERNE',$memoire_interne);
      $this->db->where_in('MEMOIRE_RAM',$memoire_ram);
      $this->db->where_in('RESOLUTION_CAM_ARRIERE',$cam_arriere);

      $this->db->where_in('RESOLUTION_CAM_AVANT',$cam_avant);
      $this->db->where_in('SYSTEME_EXPLOITATION',$systeme);
      $this->db->where_in('BATTERIE_AMOVIBLE',$batter_amovible);
      $this->db->where_in('CAPACITE_BATTERIE',$capacite_batt);
      $this->db->where_in('ECRAN_TACTILE',$ecran_tactile);

      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    

    $query = $this->db->get();
    return $query->result_array();
  }
  public function getRecord_television($marques=array(),$tailles=array(),$resolution=array(),$type_ecran=array(),$ecran_incurve=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
    {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('article_television', 'article_television.CODE_ARTICLE= article.CODE_ARTICLE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      //$this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_D_ECRAN', $tailles);
      $this->db->where_in('RESOLUTION',$resolution);
      $this->db->where_in('TYPE_ECRAN',$type_ecran);
      $this->db->where_in('ECRAN_INCURVE',$ecran_incurve);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if($tailles !=''){
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_D_ECRAN', $tailles);
      $this->db->where_in('RESOLUTION',$resolution);
      $this->db->where_in('TYPE_ECRAN',$type_ecran);
      $this->db->where_in('ECRAN_INCURVE',$ecran_incurve);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($resolution !='') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_D_ECRAN', $tailles);
      $this->db->where_in('RESOLUTION',$resolution);
      $this->db->where_in('TYPE_ECRAN',$type_ecran);
      $this->db->where_in('ECRAN_INCURVE',$ecran_incurve);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($type_ecran !='') {
      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_D_ECRAN', $tailles);
      $this->db->where_in('RESOLUTION',$resolution);
      $this->db->where_in('TYPE_ECRAN',$type_ecran);
      $this->db->where_in('ECRAN_INCURVE',$ecran_incurve);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else if ($ecran_incurve !='') {

      $this->db->where_in('MARQUE', $marques);
      $this->db->where_in('TAILLE_D_ECRAN', $tailles);
      $this->db->where_in('RESOLUTION',$resolution);
      $this->db->where_in('TYPE_ECRAN',$type_ecran);
      $this->db->where_in('ECRAN_INCURVE',$ecran_incurve);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    $query = $this->db->get();
    return $query->result_array();
  }
  public function getRecord_else($marques=array(),$rowno,$rowperpage,$criteres=array(),$minvalue,$maxvalue)
  {

    $this->db->select('*');
    $this->db->from('article');
    $this->db->join('sous_categorie', 'sous_categorie.CODE_SOUS_CATEGORIE= article.CODE_SOUS_CATEGORIE');
    $this->db->join('categorie', 'categorie.CODE_CATEGORIE= article.CODE_CATEGORIE');
    $this->db->where($criteres);
    $this->db->limit($rowperpage, $rowno);

    if($marques != '')
    {
      
      $this->db->where_in('MARQUE', $marques);
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }
    else{
      $this->db->where("PRIX_UNITAIRE BETWEEN $minvalue AND $maxvalue");
      $this->db->limit($rowperpage, $rowno);
    }

    
    
    $query = $this->db->get();
    return $query->result_array();
  }
  

 
}