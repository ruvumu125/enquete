<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller { 

	
	public function index()
	{

    $listofusers=array();
    $list_users=$this->Model->getList('utilisateur');

    foreach ($list_users as $key) {
     
     $criteres_profil['CODE_PROFIL_UTILISATEUR']=$key['CODE_PROFIL_UTILISATEUR'];
     $list_profil=$this->Model->getOne('profil_utilisateur',$criteres_profil);
     
     $nom_complet=$key['NOM_UTILISATEUR'].' '.$key['PRENOM_UTILISATEUR'];
      $listofusers[]=array(
          'nom'=>$key['NOM_UTILISATEUR'],
          'prenom'=>$key['PRENOM_UTILISATEUR'],
          'telephone'=>$key['TELEPHONE_UTILISATEUR'],
          'email'=>$key['EMAIL_UTILISATEUR'],
          'username'=>$key['USER_NAME'],
          'password'=>$key['PASSWORD'],
          'profil'=>$list_profil['DESCRIPTION_PROFIL'],

          'photo'=>"<img src='". base_url('uploads/utilisateurs/thumbs/') .$key['PHOTO_UTILISATEUR'] ."'>",
          
          'update'=>'<a class="btn btn-success btn-xs" href="' . base_url('Users/index_update/') .$key['CODE_UTILISATEUR'] . '" style="width:80px;"><i class="fa fa-edit"></i> Modifier </a>

               <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" 
                            data-target="#mydelete'.$key['CODE_UTILISATEUR'] .'" style="margin-top:5px;width:80px;"><i class="fa fa-trash"></i> Supprimer </button>
                <div class="modal fade" id="mydelete'.$key['CODE_UTILISATEUR'].'">
         <div class="modal-dialog">
          <div class="modal-content">
           <div class="modal-body">
            <h5>Voulez vous vraiment supprimer l\'utilisateur '.$nom_complet.'?</h5>
           </div>
           <div class="modal-footer">
             <a class="btn  btn-primary btn-md" href="'.base_url("Users/delete/".$key['CODE_UTILISATEUR']).'">Supprimer</a>
             <button class="btn  btn-md" class="close" data-dismiss="modal">Annuler</button>
           </div>
          </div>
         </div>
        </div>'
      );


      
    }
    $data['list']=$listofusers;
      
    $templates=array(
    'table_open' => '<table class="table table-bordered table-stripped table-hover table-condensed" id="table_id"> ',
    'table_close'  => '</table>');
    $this->table->set_heading(array('Nom','Prenom','Telephone','Email','Username','Password','Profil','Photo','Options'));

    $this->table->set_template($templates);
		$this->load->view('user_list_view',$data);
	}
	public function index_add() 
	{
		$data['list_des_profil']=$this->Model->getList('profil_utilisateur');
		$this->load->view('user_add_view',$data);
	}
	public function add(){

		$this->form_validation->set_rules('nom_utilisateur','Nom de l\'utilisateur','trim|required');
		$this->form_validation->set_rules('prenom_utilisateur','Prenom de l\'utilisateur','trim|required');
		$this->form_validation->set_rules('Telephone_utilisateur','Telephone de l\'utilisateur','trim|required');
		$this->form_validation->set_rules('email_utilisateur','Email de l\'utilisateur','trim|required|valid_email');
		$this->form_validation->set_rules('Username_utilisateur','Username de l\'utilisateur','trim|required');
		$this->form_validation->set_rules('profil_utilisateur','Profil de l\'utilisateur','trim|required');

		  $config = array(
        'upload_path' => "./uploads/utilisateurs/",
        'allowed_types' => "gif|jpg|png|jpeg",
        'overwrite' => TRUE
        );
        $this->load->library('upload', $config);

        if($this->form_validation->run()==FALSE && !$this->upload->do_upload()){
           
           $data['nom_utilisateur']=$this->input->post('nom_utilisateur');
           $data['prenom_utilisateur']=$this->input->post('prenom_utilisateur');
           $data['Telephone_utilisateur']=$this->input->post('Telephone_utilisateur');
           $data['email_utilisateur']=$this->input->post('email_utilisateur');
           $data['Username_utilisateur']=$this->input->post('Username_utilisateur');
           $data['profil_utilisateur']=$this->input->post('profil_utilisateur');

           $data['message']= '';
           $data['list_profil']=$this->Model->getList('profil_utilisateur');
           $data['error']=$this->upload->display_errors();
           $this->load->view('user_add_view',$data);
        }
        else{
            
            $code_user=uniqid();
            $this->upload->do_upload('photo_user');
            $data_image=$this->upload->data();
            $config=array(

             'image_library'=>'GD2',
             'source_image'=>$data_image['full_path'],
             'new_image'=>'./uploads/utilisateurs/thumbs/',
             'create_thumb'=>TRUE,
             'thumb_marker'=>'',
             'maintain_ratio'=>TRUE,
             'width'=>128,
             'height'=>128
             );
            $this->load->library('image_lib',$config);
            $this->image_lib->resize();
            $image_name_main=$data_image['file_name'];

            $NOM=$this->input->post('nom_utilisateur');
            $PRENOM=$this->input->post('prenom_utilisateur');
            $EMAIL=$this->input->post('email_utilisateur');
            $TELEPHONE=$this->input->post('Telephone_utilisateur');
            $USERNAME=$this->input->post('Username_utilisateur');
            $CODE_PROFIL=$this->input->post('profil_utilisateur');
            $PASSWORD = $this->notifications->generate_password(6);//generation du mot de passe
            $NOM_COMPLET=$NOM.' '.$PRENOM;

            $data=array(
                'NOM_UTILISATEUR'=>$NOM,
                'PRENOM_UTILISATEUR'=>$PRENOM,
                'TELEPHONE_UTILISATEUR'=>$TELEPHONE,
                'EMAIL_UTILISATEUR'=>$EMAIL,
                'USER_NAME'=>$USERNAME,
                'PASSWORD'=>$PASSWORD,
                'PHOTO_UTILISATEUR'=>$image_name_main,
                'CODE_UTILISATEUR'=>$code_user,
                'CODE_PROFIL_UTILISATEUR'=>$CODE_PROFIL
             );
            $this->Model->create('utilisateur',$data);
            
            $message = "Monsieur /Madame ".$this->input->post('nom_utilisateur').' '.$this->input->post('prenom_utilisateur')."  </br></br>Voici vos Coordonnées d'autentification sur la plateforme Goshen Cooperative.<br><br>";
    $message .= "Username: <b>".$this->input->post('Username_utilisateur')."</b><br>Mot de passe: <b>".$PASSWORD."</b><br>Merci cordialement.";
    $this->notifications->rungika(trim($this->input->post('email_utilisateur')),'Coordonne pour la plateforme Goshen Cooperative' ,NULL,$message,NULL);
    
            $this->session->set_flashdata('feedback', 'Enregistré');
            redirect(base_url('Users/'));
        }

	}

	public function index_update()
	{
        $criteres_cat['CODE_UTILISATEUR']=$this->uri->segment(3);
        $data['get_utilisateurs']=$this->Model->getOne('utilisateur',$criteres_cat);
        $les_utilisateurs=$this->Model->getOne('utilisateur',$criteres_cat);
        $criteres_profil['CODE_PROFIL_UTILISATEUR']=$les_utilisateurs['CODE_PROFIL_UTILISATEUR'];
        $data['mes_etilisateurs']=$this->Model->getOne('profil_utilisateur',$criteres_profil);

        $data['liste_des_profils']=$this->Model->getList('profil_utilisateur');

		$this->load->view('user_update_view',$data);
	}
    public function update()
    {
        $critero['CODE_UTILISATEUR'] = $this->input->post('code_utilisateur');

        $this->form_validation->set_rules('nom_utilisateur','Nom de l\'utilisateur','trim|required');
        $this->form_validation->set_rules('prenom_utilisateur','Prenom de l\'utilisateur','trim|required');
        $this->form_validation->set_rules('Telephone_utilisateur','Telephone de l\'utilisateur','trim|required');
        $this->form_validation->set_rules('email_utilisateur','Email de l\'utilisateur','trim|required|valid_email');
        $this->form_validation->set_rules('Username_utilisateur','Username de l\'utilisateur','trim|required');
        $this->form_validation->set_rules('profil_utilisateur','Profil de l\'utilisateur','trim|required');

        if($this->form_validation->run()==FALSE){
           
           $data['message']= '';
           
           
           $data['get_utilisateurs']=$this->Model->getOne('utilisateur',$critero);
           $les_utilisateurs=$this->Model->getOne('utilisateur',$critero);
           $criteres_profil['CODE_PROFIL_UTILISATEUR']=$les_utilisateurs['CODE_PROFIL_UTILISATEUR'];
           $data['mes_etilisateurs']=$this->Model->getOne('profil_utilisateur',$criteres_profil);
           $data['list_profil']=$this->Model->getList('profil_utilisateur');
           $this->load->view('user_update_view',$data);
        }
        else{


        $NOM=$this->input->post('nom_utilisateur');
        $PRENOM=$this->input->post('prenom_utilisateur');
        $EMAIL=$this->input->post('email_utilisateur');
        $TELEPHONE=$this->input->post('Telephone_utilisateur');
        $USERNAME=$this->input->post('Username_utilisateur');
        $CODE_PROFIL=$this->input->post('profil_utilisateur');
        $NOM_COMPLET=$NOM.' '.$PRENOM;
        

         //Uploader iphoto princiale
       $image_name_main;

      if (!empty($_FILES['new_photo']['name'])) {
       
       $config['upload_path'] ='./uploads/utilisateurs/';
       $config['allowed_types'] = 'gif|jpg|png';
      
       $this->load->library('upload', $config);
       $this->upload->do_upload('new_photo');
       $data_image=$this->upload->data();
       $config=array(

        'image_library'=>'GD2',
        'source_image'=>$data_image['full_path'],
        'new_image'=>'./uploads/utilisateurs/thumbs/',
        'create_thumb'=>TRUE,
        'thumb_marker'=>'',
        'maintain_ratio'=>TRUE,
        'width'=>50,
        'height'=>50
       );
       $this->load->library('image_lib',$config);
       $this->image_lib->resize();
       $remov=$this->Model->getList('utilisateur',$critero);
         foreach ($remov as $row) {
           unlink('./uploads/utilisateurs/'.$row['PHOTO_UTILISATEUR']);
           unlink('./uploads/utilisateurs/thumbs/'.$row['PHOTO_UTILISATEUR']);
         }
       $image_name_main=$data_image['file_name'];
      }
      else{
        $roi=$this->Model->getOne('utilisateur',$critero);
        $image_name_main=$roi['PHOTO_UTILISATEUR'];

      }

        
        $data_utilisateur=array(
                'NOM_UTILISATEUR'=>$NOM,
                'PRENOM_UTILISATEUR'=>$PRENOM,
                'TELEPHONE_UTILISATEUR'=>$TELEPHONE,
                'EMAIL_UTILISATEUR'=>$EMAIL,
                'USER_NAME'=>$USERNAME,
                'PHOTO_UTILISATEUR'=>$image_name_main,
                'CODE_PROFIL_UTILISATEUR'=>$CODE_PROFIL
             );

      if ( $this->Model->update('utilisateur', $critero, $data_utilisateur)) {
               
               $this->session->set_flashdata('feedback', 'Updated');
               redirect(base_url('Users/'));
            }
        }
   

    }
    public function delete(){
        $table ='utilisateur';
        $criteres['CODE_UTILISATEUR']=$this->uri->segment(3);
        $data['rows']= $this->Model->getOne( $table,$criteres);

        $this->Model->delete($table,$criteres);
        $this->session->set_flashdata('feedback', 'Updated');
            redirect(base_url('Users/'));
  }
}
