<?php
    include 'includes/header.php'; 
?>

<?php
    include 'includes/entete.php';
?>

<?php
    
    $dashboard='';

    $gestion_reception='active';
    $clients='active';
    $hebergement='';
    $chambres_libres='';
    $chambres_occupes='';
    $reservation='';
    $reglement='';


    $parametres='';
    $chambres='';
    $types_chambres='';
    $services='';
    $nationalites='';

    include 'includes/partie_gauche.php';
?>

 <style type="text/css">
    .flashmessage {
    background: #4cb445;
    color: #f1f1f1;
    padding: 3px;
    font-size: 21px;
    text-align: center;
    width: 212px;
    margin-left: 20px;
    margin-top: 10px;
}
.pull-left {
    float: left!important; 
} 
 </style>   

    
<div class="content-wrapper" style="min-height: 355px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Banque
           <!-- <small>Version 100.2</small> -->
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
    
    <!--Message de succes-->
    <?php $message = $this->session->flashdata('feedback');?>
    <?php if(!empty($message)):?>
      <div class="flashmessage text-center pull-right" style="margin-right: 51%;"><i class="fa fa-check"></i> <?php echo $message; ?></div>
    <?php endif;?>
    <!--Fin Message de succes-->
    
    <!-- Main content -->
    <section class="content">
        <div class="col-md-3 row pull-left" style="padding-right: 0px;">
            <a href="<?php echo base_url()?>Clients/index_add" type="button" class="btn btn-block btn-primary pull-right btn-success">Ajouter une nouvelle banque</a>
        </div>

        <br><br>
        <!--        Filters Box-->
        
        <!--        End Of Filters Box-->

        <div class="row">

            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Liste des banques</h3>
                    </div>

                    <div class="box-body">
                        <?= $this->session->flashdata('message') ?>
                       <br>
                       <?php echo $this->table->generate($list);?>
                    </div>

                </div>
            </div>


        </div><!-- /.row -->
    </section><!-- /.content -->


    
</div><!-- /.content-wrapper -->


<?php
    include 'includes/pied_page.php';
?>

<?php
    include 'includes/footer.php';
?>

<script>
  
$(document).ready(function(){
  
    $(document).ready( function () {
    $('#table_id').DataTable({

      "columnDefs": [
    { "width": "10%", "targets": 0 },{ "width": "3%", "targets": 1 }
  ]
    });
} );
  });
</script>

<script>
  
$(document).ready(function(){
  
   setTimeout(function(){  
                               $('.flashmessage').fadeOut("Slow");  
                          }, 3000);
  });
</script>