<header class="main-header">

        <!-- Logo -->
        <a href="<?php echo base_url()?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b>G</b>SN</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg size">GOSHEN</span>  
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>  
    </a>
    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
            <!-- User Account: style can be found in dropdown.less -->
            <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">

                    <?php if(!empty($this->session->userdata('PHOTO'))):?>
                    <img src="<?php echo base_url()?>uploads/utilisateurs/thumbs/<?= $this->session->userdata('PHOTO') ?>" class="user-image" alt="User Image">
                    <?php else:?>
                    <img src="<?php echo base_url()?>assets/dist/img/default-doctor-avatar.png" class="user-image" alt="User Image">
                    <?php endif;?>

                    <span class="hidden-xs"><?= $this->session->userdata('NOM_USER') ?> <?= $this->session->userdata('PRENOM_USER') ?></span>
                </a>
                <ul class="dropdown-menu">
                    <!-- User image -->
                    <li class="user-header">
                        <?php if(!empty($this->session->userdata('PHOTO'))):?>
                        <img src="<?php echo base_url()?>uploads/utilisateurs/<?= $this->session->userdata('PHOTO') ?>" class="img-circle" alt="User Image">
                        <?php else:?>
                        <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" class="img-circle" alt="User Image">
                        <?php endif;?>
                        <p>
                            <?= $this->session->userdata('NOM_USER') ?> <?= $this->session->userdata('PRENOM_USER') ?>
                        </p>
                    </li>
                    <!-- Menu Footer-->
                    <li class="user-footer">
                        <div class="pull-left">
                            <a href="<?php echo base_url()?>ChangePassword/" class="btn btn-default btn-flat">Modifier password</a>
                        </div>

                        <div class="pull-right">
                            <a href="<?php echo base_url()?>Login/do_logout" class="btn btn-default btn-flat">Déconnexion</a>
                        </div>
                    </li>
                </ul>
            </li>
            <!-- Control Sidebar Toggle Button -->
            <li>
                <a href="#" data-toggle="control-sidebar"></a>
            </li>
        </ul>
    </div>
    </nav> 
    </header>